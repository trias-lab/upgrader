# txmodule
**trias txmodule**

trias交易模块，主要提供trias交易,余额查询等功能。该模块依赖账号服务模块，需要先启动tribc服务,
待tribc服务成功启动以后，再打开txmodule目录并执行:python3 main.py

**安装**  
该模块使用python3编写，需要安装python3以及相应的模块。  
启动命令：_python3 main.py_，默认端口号：9981  

**功能**  
utxo模块提供了如下功能：    
1.账号申请，返回用户地址，生成公钥私钥文件。  
2.账号查询，返回本地保存的地址。  
3.生成货币，由于token经济还未确定，为了测试交易，先将该接口放出。  
4.交易转账，账号之间交易货币  
5.查询余额，返回地址余额  

**API**  
可以使用Postman或curl命令进行模拟操作  
1.账号申请接口  
GET方法， http://xx.xx.xx.xx:9981/new_account  
2.账号查询接口  
GET方法， http://xx.xx.xx.xx:9981/get_accounts  
3.生成货币  
POST方法，http://xx.xx.xx.xx:9981/new_coinbase_tx  
参数：to_address  值：账号地址  
4.交易转账  
POST方法，http://xx.xx.xx.xx:9981/new_utxo_transaction  
参数：from_address 值：交易支付地址  
参数：to_address  值：交易接受地址  
参数：amount  值：交易金额（目前只支持整数）  
5.查询余额  
GET方法， http://xx.xx.xx.xx:9981/get_balance  
参数：address 值：账号地址  
