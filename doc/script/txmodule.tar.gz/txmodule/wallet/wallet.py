#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os
from rpc.account_rpc import AccountRPC
from config import config


class Wallet:
    def __init__(self, account_file=None):
        self.account_file = account_file
        self.rpc = AccountRPC((config.ACCOUNT_HOST, config.ACCOUNT_PORT))
        if account_file and os.path.exists(self.account_file):
            self.rpc.call("AccRPC.ImportAcc", {"path": self.account_file, "pass": "1234qwer"})

    def new_account(self):
        account = self.rpc.call("AccRPC.CreateAcc", {"path": self.account_file, "pass": "1234qwer"})
        return account

    def get_account_list(self):
        acc_list = self.rpc.call("AccRPC.GetAcclist", "GetAcclist")
        return acc_list

    def sign(self, addr, data, pwd):
        sig_resp = self.rpc.call("AccRPC.Sign", {"addr": addr, "hash": data, "pass": pwd})
        return sig_resp

    def verify(self, pub_key, data, sign_data):
        is_verify = self.rpc.call("AccRPC.Verify", {"pubkey": pub_key, "hash": data, "stext": sign_data})
        return is_verify

    def verify_shield(self, priva, shield_addr, shield_pkey):
        is_verify = self.rpc.call("AccRPC.Verify_shield2", {"priva": priva, "shieldaddr": shield_addr, "shieldpkey": shield_pkey})
        return is_verify

    def get_prove_data(self, post_body):
        response = self.rpc.call("AccRPC.ZK_GetProveData", post_body)
        return response

    def check_prove_data(self, req_data):
        response = self.rpc.call("AccRPC.ZK_CheckProveData", req_data)
        return response

    def close(self):
        self.rpc.close()
