# -*- coding: utf-8 -*-
"""
  logger
  使用说明：此日志是对logging的封装

  写日志到Console和带时间切割策略的File:
      logger = make_8lab_console_time_logger()

"""

import os
import sys
import platform
import logging
import logging.handlers

DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
LOG_FORMAT = '%(asctime)s [%(levelname)s] [%(module)s:%(funcName)s] [%(lineno)d] - %(message)s'
# LOG_LEVEL = logging.DEBUG
LOG_LEVEL = logging.ERROR
FORMATTER = logging.Formatter(LOG_FORMAT, DATE_FORMAT)

if platform.system() == 'Linux':
    LOG_DIR = os.path.sep + "trias" + os.path.sep + "log"
    LOG_FILENAME = os.path.sep + "trias" + os.path.sep + "log" + os.path.sep + "tri_tx_module.log"
elif platform.system() == 'Windows':
    LOG_DIR = "c:" + os.path.sep + "trias" + os.path.sep + "log"
    LOG_FILENAME = "c:" + os.path.sep + "trias" + os.path.sep + "log" + os.path.sep + "tri_tx_module.log"
else:  # for MAC os
    LOG_DIR = os.path.sep + "trias" + os.path.sep + "log"
    LOG_FILENAME = os.path.sep + "trias" + os.path.sep + "log" + os.path.sep + "tri_tx_module.log"


def __console_handler():
    """
    写日志到Console
    :return: console_handler
    """
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(FORMATTER)
    return console_handler


def __time_handler():
    """
    切割日志
    :return: __time_handler
    """
    time_handler = logging.handlers.TimedRotatingFileHandler(LOG_FILENAME, 'MIDNIGHT', 1, 0)
    time_handler.setFormatter(FORMATTER)
    # 切割后的日志设置后缀
    time_handler.suffix = '%Y%m%d'
    return time_handler


def make_8lab_console_time_logger():
    """
    定义日志对象,实现同时写入Console和文件"/trias/log/tri_tx_module.log",并且可以切割
    :return:  logger
    """
    common_logger = logging.getLogger("tx_module")
    common_logger.setLevel(LOG_LEVEL)
    common_logger.addHandler(__console_handler())
    common_logger.addHandler(__time_handler())
    return common_logger


if not os.path.isdir(LOG_DIR):
    os.makedirs(LOG_DIR)

if not os.path.isfile(LOG_FILENAME):
    open(LOG_FILENAME, 'w+')

LOGGER = make_8lab_console_time_logger()
