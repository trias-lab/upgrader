class Result:
    def __init__(self, status, msg, data):
        self.status = status
        self.msg = msg
        self.data = data
