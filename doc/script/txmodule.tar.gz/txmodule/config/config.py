#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
    配置文件
"""

from utils.net_utils import get_host_ip

# ACCOUNT_HOST = "192.168.1.171"
ACCOUNT_HOST = "127.0.0.1"
ACCOUNT_PORT = 9876


SUBSIDY = 100  # 挖矿奖励

TM_IP = get_host_ip()
if not TM_IP:
    TM_IP = "127.0.0.1"
TM_PORT = 46657
TM_URL = "http://" + TM_IP + ":" + str(TM_PORT)
