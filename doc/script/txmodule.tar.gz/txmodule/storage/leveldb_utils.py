#!/usr/bin/env python
# -*- coding:utf-8 -*-
import hashlib
import pickle
import leveldb

UTXO_SET_KEY = "utxoset"  # 保存UTXO
CLEARTEXT_ADDRESS_TX_KEY = "cleartextaddrtx"  # 保存明文地址相关的交易
ANONYMOUS_ADDRESS_TX_KEY = "anonymousaddrtx"  # 保存匿名地址相关的交易
TRANSACTION_NUM_KEY = "transactionnum"  # 保存交易总数
LATEST_TRANSACTIONS_KEY = "latesttransactions"  # 保存最近的10条交易
LATEST_TRAN_ADDRESS_KEY = "latesttranaddress"   # 保存最近交易的10个地址
APP_HASH_KEY = "apphash"    # 保存UXTO模块的apphash
# leveldb缓存 等commit值之后再将缓存中的数据更新至leveldb中
DB_CACHE = {}


class LeveldbUtils:
    def __init__(self, db_dir):
        # 初始化db
        self.db = leveldb.LevelDB(db_dir)
        # 初始化UTXO池
        self.utxoset_bucket = self.init_utxoset()  # 格式：{tx_id: {index:utxo, index:utxo...}}
        # 初始化明文地址相关交易 该变量主要向钱包提供地址相关交易查询功能 记录和每个地址相关的交易，在这笔交易中是发送方还是接受方
        self.cleartext_addr_tx_bucket = self.init_cleartext_addr_tx()  # 格式：{address: [{"type":"send", "tx": tx}...]}
        # 初始化匿名地址相关交易 由于匿名地址交易每次地址都不相同，如果用地址作为key则没有规律可寻，所以该用交易id作为key，方便解析
        self.anonymous_addr_tx_bucket = self.init_anonymous_addr_tx()  # 格式: {tx_id:[{...},{...}]...}
        # 初始化交易总数
        self.transaction_num_bucket = self.init_transaction_num()  # 整数
        # 保存最近的10条交易
        self.latest_transactions_bucket = self.init_latest_transactions()  # 格式：[{id:xxx, from:xxx, to:xxx, time:xx}]
        # 初始化最近交易的10个地址
        self.latest_tran_address_bucket = self.init_latest_tran_address()  # 格式：[address,address....]
        # 初始化apphash
        self.app_hash_bucket = self.init_app_hash()

    def get_utxoset_bucket(self):
        return self.utxoset_bucket

    def get_cleartext_addr_tx_bucket(self):
        return self.cleartext_addr_tx_bucket

    def get_anonymous_addr_tx_bucket(self):
        return self.anonymous_addr_tx_bucket

    def init_utxoset(self):
        """
        初始化UTXT池
        :return:
        """
        byte_chainstate = UTXO_SET_KEY.encode("utf-8")
        # 判断leveldb中是否存在chainstate  不存在创建，存在则直接读取
        if not self.exist(UTXO_SET_KEY):
            value = {}
            p_value = pickle.dumps(value)
            self.db.Put(byte_chainstate, p_value)
            return value
        else:
            v_chainstate = self.db.Get(byte_chainstate)
            return pickle.loads(v_chainstate)

    def init_cleartext_addr_tx(self):
        """
        初始化明文地址交易
        :return:
        """
        address_key = CLEARTEXT_ADDRESS_TX_KEY.encode("utf-8")
        # 判断leveldb中是否存在address bucket  不存在创建，存在则直接读取
        if not self.exist(CLEARTEXT_ADDRESS_TX_KEY):
            value = {}
            p_value = pickle.dumps(value)
            self.db.Put(address_key, p_value)
            return value
        else:
            cleartext_addr_txs = self.db.Get(address_key)
            return pickle.loads(cleartext_addr_txs)

    def init_anonymous_addr_tx(self):
        """
        初始化匿名地址交易
        :return:
        """
        address_key = ANONYMOUS_ADDRESS_TX_KEY.encode("utf-8")
        # 判断leveldb中是否存在address bucket  不存在创建{}，存在则直接读取
        if not self.exist(ANONYMOUS_ADDRESS_TX_KEY):
            value = {}
            p_value = pickle.dumps(value)
            self.db.Put(address_key, p_value)
            return value
        else:
            anonymous_addr_txs = self.db.Get(address_key)
            return pickle.loads(anonymous_addr_txs)

    def init_transaction_num(self):
        """
        初始化交易总数
        :return:
        """
        trans_num_key = TRANSACTION_NUM_KEY.encode("utf-8")
        if not self.exist(TRANSACTION_NUM_KEY):
            value = 0
            p_value = pickle.dumps(value)
            self.db.Put(trans_num_key, p_value)
            return value
        else:
            trans_num = self.db.Get(trans_num_key)
            return pickle.loads(trans_num)

    def init_latest_transactions(self):
        latest_trans_key = LATEST_TRANSACTIONS_KEY.encode("utf-8")
        if not self.exist(LATEST_TRANSACTIONS_KEY):
            value = []
            p_value = pickle.dumps(value)
            self.db.Put(latest_trans_key, p_value)
            return value
        else:
            latest_trans = self.db.Get(latest_trans_key)
            return pickle.loads(latest_trans)

    def init_latest_tran_address(self):
        latest_trans_address_key = LATEST_TRAN_ADDRESS_KEY.encode("utf-8")
        if not self.exist(LATEST_TRAN_ADDRESS_KEY):
            value = []
            p_value = pickle.dumps(value)
            self.db.Put(latest_trans_address_key, p_value)
            return value
        else:
            latest_tran_address = self.db.Get(latest_trans_address_key)
            return pickle.loads(latest_tran_address)

    def init_app_hash(self):
        """
        初始化apphash
        :return:
        """
        app_hash_key = APP_HASH_KEY.encode("utf-8")
        if not self.exist(APP_HASH_KEY):
            value = "0" * 40
            p_value = pickle.dumps(value)
            self.db.Put(app_hash_key, p_value)
            return value
        else:
            app_hash = self.db.Get(app_hash_key)
            return pickle.loads(app_hash)

    def exist(self, key):
        """
        判断是否存在key
        :param key:
        :return:
        """
        try:
            _key_obj = key.encode("utf-8")
            self.db.Get(_key_obj)
            return True
        except KeyError:
            return False

    def clear_chainstate(self):
        self.utxoset_bucket.clear()

    def clear_addressbucket(self):
        self.cleartext_addr_tx_bucket.clear()

    def put_utxos(self, tx_id, utxos):
        """
        :param tx_id: 交易id
        :param utxos: utxos
        :return:
        """
        if tx_id and utxos:
            self.utxoset_bucket[tx_id] = utxos
            self.db.Put(UTXO_SET_KEY.encode("utf-8"), pickle.dumps(self.utxoset_bucket))

    def get_utox_by_txid(self, tx_id):
        if tx_id in self.utxoset_bucket.keys():
            utxos = self.utxoset_bucket[tx_id]
            return utxos
        else:
            return {}

    def del_utxo_by_txid(self, tx_id):
        if tx_id in self.utxoset_bucket.keys():
            del self.utxoset_bucket[tx_id]
            self.db.Put(UTXO_SET_KEY.encode("utf-8"), pickle.dumps(self.utxoset_bucket))

    def put_cleartext_tx_by_addr(self, address, tx_dict):
        """
        保存明文地址相关交易
        :param address: 账户地址
        :param tx_dict: 交易dict
        :return:
        """
        if address not in self.cleartext_addr_tx_bucket.keys():
            self.cleartext_addr_tx_bucket[address] = []

        self.cleartext_addr_tx_bucket[address].append(tx_dict)
        self.db.Put(CLEARTEXT_ADDRESS_TX_KEY.encode("utf-8"), pickle.dumps(self.cleartext_addr_tx_bucket))

    def put_anonymous_tx_by_id(self, tx_id, tx_dict):
        """
        保存匿名地址交易
        :param tx_id: 交易id
        :param tx_dict: 交易的输入和输出
        :return:
        """
        if tx_id not in self.anonymous_addr_tx_bucket.keys():
            self.anonymous_addr_tx_bucket[tx_id] = []

        self.anonymous_addr_tx_bucket[tx_id].append(tx_dict)
        self.db.Put(ANONYMOUS_ADDRESS_TX_KEY.encode("utf-8"), pickle.dumps(self.anonymous_addr_tx_bucket))

    def put_transaction_num(self, num):
        if int(num) > self.transaction_num_bucket:
            self.transaction_num_bucket = int(num)
            self.db.Put(TRANSACTION_NUM_KEY.encode("utf-8"), pickle.dumps(self.transaction_num_bucket))

    def get_transaction_num(self):
        """
        获取交易总数
        :return:
        """
        return self.transaction_num_bucket

    def get_latest_transactions(self):
        return self.latest_transactions_bucket

    def update_latest_transactions(self, tx):
        """
        更新最近的交易，新的入队列，旧的交易出队列
        :param tx:
        :return:
        """
        if len(self.latest_transactions_bucket) < 10:
            self.latest_transactions_bucket.append(tx)
        else:
            self.latest_transactions_bucket.pop(0)
            self.latest_transactions_bucket.append(tx)

        self.db.Put(LATEST_TRANSACTIONS_KEY.encode("utf-8"), pickle.dumps(self.latest_transactions_bucket))

    def get_latest_tran_address(self):
        """
        获取最新的交易地址
        :return:
        """
        return self.latest_tran_address_bucket

    def update_latest_tran_address(self, address):
        """
        更新最新交易
        :param address:
        :return:
        """
        if len(self.latest_tran_address_bucket) < 10:
            self.latest_tran_address_bucket.append(address)
        else:
            self.latest_tran_address_bucket.pop(0)
            self.latest_tran_address_bucket.append(address)

        self.db.Put(LATEST_TRAN_ADDRESS_KEY.encode("utf-8"), pickle.dumps(self.latest_tran_address_bucket))

    def put_app_hash(self, app_hash):
        """
        保存app hash
        :param app_hash:
        :return:
        """
        self.app_hash_bucket = app_hash
        self.db.Put(APP_HASH_KEY.encode("utf-8"), pickle.dumps(self.app_hash_bucket))

    def get_app_hash(self):
        return self.app_hash_bucket

    def update_utxoset_bucket(self, utxo_bucket):
        self.utxoset_bucket = utxo_bucket
        self.db.Put(UTXO_SET_KEY.encode("utf-8"), pickle.dumps(self.utxoset_bucket))

    def update_anonymous_addr_tx_bucket(self, anonymous_bucket):
        self.anonymous_addr_tx_bucket = anonymous_bucket
        self.db.Put(ANONYMOUS_ADDRESS_TX_KEY.encode("utf-8"), pickle.dumps(self.anonymous_addr_tx_bucket))

    def update_cleartext_addr_tx_bucket(self, cleartext_bucket):
        self.cleartext_addr_tx_bucket = cleartext_bucket
        self.db.Put(CLEARTEXT_ADDRESS_TX_KEY.encode("utf-8"), pickle.dumps(self.cleartext_addr_tx_bucket))
