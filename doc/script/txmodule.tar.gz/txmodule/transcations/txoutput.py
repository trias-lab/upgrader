#!/usr/bin/env python
# -*- coding:utf-8 -*-

from utils.base58 import base58decode


class TxOutput:
    """
    交易输出
    """

    def __init__(self, value, address, shield_pkey="", value_encrypt=""):
        self.value = value
        self.pub_key_hash = address     # TODO 以后需要传入加密以后的公钥
        self.shield_pkey = shield_pkey
        self.value_encrypt = value_encrypt  # value加密之后的字符串

    def lock(self, address):
        """
        转换hash值
        :param address:
        :return:
        """
        pub_key_hash = base58decode(address)
        pub_key_hash = pub_key_hash[1:len(pub_key_hash) - 4]
        return pub_key_hash

    def is_locked_with(self, pub_key_hash):
        """
        检查交易输出是否能使用指定的公钥
        """
        return self.pub_key_hash == pub_key_hash
