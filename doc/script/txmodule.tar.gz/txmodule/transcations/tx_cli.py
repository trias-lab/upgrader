#!/usr/bin/env python
# -*- coding:utf-8 -*-
"""
    交易工具类，主要提供：
    1.新建交易
    2.查询交易
    3.查询余额
    4.交易签名
    5.交易验证
    6.coinbase交易(暂定，以后会去去除)
"""

import json
import base64
import requests

from logs.tx_log import LOGGER
from config.config import SUBSIDY, TM_URL
from .transaction import Transaction
from .txinput import TxInput
from .txoutput import TxOutput
from storage.leveldb_utils import DB_CACHE


def new_coinbase_tx(to_address):
    """
    Coin Baise交易  挖矿奖励
    :param to_address:
    :return:
    """
    # 交易输入
    txin = TxInput("", -1, "", "www.8lab.cn", "www.trias.one")
    # 交易输出
    txout = TxOutput(SUBSIDY, to_address)
    # 创建交易
    tx = Transaction(None, [txin], [txout])
    # 交易ID
    tx.hash()

    return tx


def new_utxo_transaction(from_address, to_address, amount, utxo_set):
    """
    创建新utxo交易
    :param from_address: 起始地址
    :param to_address: 转账地址
    :param amount: 转账金额
    :param utxo_set: utxo池
    :return:
    """
    result = {"code": "failure",
              'msg': '',
              'tx': None}

    accumulated, unspent_outs = utxo_set.find_spendable_outputs(from_address, amount)

    # 查询是否有足够余额
    if accumulated < int(amount) or not unspent_outs:
        LOGGER.error("not enough funds.")
        result['msg'] = "Not enough funds."
        return result

    try:
        tx_inputs = []
        for tx_id in unspent_outs.keys():
            for tx_out_index in unspent_outs[tx_id]:
                tx_input = TxInput(tx_id, tx_out_index, "", from_address)
                tx_inputs.append(tx_input)

        tx_outputs = []
        tx_out = TxOutput(int(amount), to_address)
        tx_outputs.append(tx_out)

        if accumulated > int(amount):
            tx_outputs.append(TxOutput(accumulated - int(amount), from_address))

        tx = Transaction(None, tx_inputs, tx_outputs)
        tx.hash()

        result['code'] = 'success'
        result['tx'] = tx
    except Exception as e:
        result['msg'] = str(e)

    return result


def get_balance(address, utxo_set, priva=None, wallet=None):
    """
    查询余额度
    :param address: 地址
    :param utxo_set: utxo池
    :param priva: 查询密钥
    :param wallet: 钱包
    :return:
    """
    balance = 0  # 明文地址交易余额
    balance_hide_amount = []  # 明文地址隐藏金额交易余额
    crypto_balance = 0  # 隐私地址交易余额
    crypto_balance_hide_amount = []  # 隐私地址隐藏金额交易余额

    if priva:
        utxos = utxo_set.find_utxos_by_address(address, priva, wallet)
    else:
        utxos = utxo_set.find_utxos_by_address(address)

    for u_key in utxos.keys():
        for utxo in utxos[u_key]:
            if u_key == "normal":
                if isinstance(utxo.value, int):
                    balance = balance + utxo.value
                else:
                    balance_hide_amount.append(utxo.value_encrypt)
            if u_key == "crypto":
                if isinstance(utxo.value, int):
                    crypto_balance = crypto_balance + utxo.value
                else:
                    crypto_balance_hide_amount.append(utxo.value_encrypt)

    return balance, balance_hide_amount, crypto_balance, crypto_balance_hide_amount


def find_tx(tx_id):
    """
    通过tx_id查询交易
    :param tx_id:
    :return:
    """
    result = {'code': 'error',
              'msg': '',
              'tx': None
              }

    # query_url = TM_URL + "/tx?hash=0x" + tx_id
    query_url = TM_URL + "/tri_block_tx?hash=0x" + tx_id

    try:
        resp = requests.get(query_url)
        resp = json.loads(resp.content.decode("utf-8"))
        if not resp["error"]:
            result['code'] = "success"
            tx = resp['result']['tx']
            tx = base64.b64decode(tx).decode("utf-8")
            tx = json.loads(tx.replace("'", '"', -1))

            transaction = json_to_tx(tx)

            result['code'] = "success"
            result['tx'] = transaction
        else:
            result['msg'] = resp['error']
    except Exception as e:
        result['msg'] = str(e)

    return result


def sign_tx(tx, private_key, wallet):
    """
    签名交易
    :param tx: Transaction
    :param private_key:
    :param wallet:
    :return:
    """
    is_signed = False

    if tx.is_coinbase():
        return True

    prev_tx_dict = {}
    try:
        for vin in tx.Vin:
            prev_tx_id = vin.tx_id
            prev_tx = find_tx(prev_tx_id)
            if prev_tx['code'] == "error":
                LOGGER.error(prev_tx['msg'])
                return False
            prev_tx = prev_tx['tx']

            prev_tx_dict[prev_tx.ID] = prev_tx

        # 签名
        tx.sign(private_key, prev_tx_dict, wallet)
        is_signed = True
    except Exception as e:
        LOGGER.error(e)

    return is_signed


def check_tx(tx, wallet):
    """
    验证交易
    :param tx:
    :param wallet:
    :return:
    """
    if tx.is_coinbase():
        return True

    result = False

    # 验证签名是否正确
    prev_tx_dict = {}
    try:
        for vin in tx.Vin:
            prev_tx_id = vin.tx_id
            prev_tx = find_tx(prev_tx_id)
            prev_tx = prev_tx['tx']

            prev_tx_dict[prev_tx.ID] = prev_tx

        # 验证
        result = tx.verify(prev_tx_dict, wallet)
        # 校验隐藏交易金额
        # TODO
    except Exception as e:
        LOGGER.error(e)

    return result


def deliver_tx(tx, utxo_set, level_db):
    """
    执行交易，更新状态
    :param tx:
    :param utxo_set:
    :param level_db:
    :return:
    """
    is_delivered = False
    try:
        # 1.验证UTXO是否存在
        if not tx.is_coinbase():
            for vin in tx.Vin:
                tx_id = vin.tx_id
                output_index = vin.tx_output_index
                indexes = utxo_set.find_utxos_by_txid(tx_id)
                if int(output_index) not in indexes:
                    LOGGER.error("deliver error: the utxo not exist.")
                    return is_delivered

        # 2.更新UTXO池
        is_delivered = utxo_set.update_utxo_by_tx(tx)

        # 3.更新address bucket
        if tx.is_coinbase():
            vout = tx.Vout[0]

            addr_tx = {
                "type": "receive",
                "tx_id": tx.ID,
                "from": "mine",
                "to": vout.pub_key_hash,
                "amount": vout.value,
                "is_anonymous": False,
                "timestamp": tx.timestamp
            }

            if vout.shield_pkey:  # 隐藏地址
                addr_tx["is_anonymous"] = True
                addr_tx["shield_pkey"] = vout.shield_pkey

                DB_CACHE['anonymous_tx'][tx.ID] = [addr_tx]
                # level_db.put_anonymous_tx_by_id(tx.ID, addr_tx)
            else:
                DB_CACHE['cleartext_tx'][vout.pub_key_hash] = [addr_tx]
                # level_db.put_cleartext_tx_by_addr(vout.pub_key_hash, addr_tx)
        else:
            # 判断是否是隐藏地址交易
            if tx.Vout[0].shield_pkey:
                is_anonymous_tx = True
            else:
                is_anonymous_tx = False

            # 如果是隐藏地址交易
            if is_anonymous_tx:
                # 由于没有隐藏地址的查询密钥，所以这边无法判断是谁向谁转了多少金额，只能暂将所有的输入和输出保存
                # 在查询时，通过查询密钥，以及交易ID来判断，每笔交易中 谁向谁发起交易, 判断逻辑在main.py中 查询地址相关交易接口中有描述
                # 每笔隐藏地址交易 由一个send 和 一个receive组成

                DB_CACHE['anonymous_tx'][tx.ID] = []

                send_tx = {
                    "type": "send",
                    "from_tx_id": tx.Vin[0].tx_id,
                    "from_tx_output_index": tx.Vin[0].tx_output_index,
                    "timestamp": tx.timestamp
                }
                DB_CACHE['anonymous_tx'][tx.ID].append(send_tx)
                # level_db.put_anonymous_tx_by_id(tx.ID, send_tx)

                receive_tx = {
                    "type": "receive",
                    "content": tx.Vout,
                    "timestamp": tx.timestamp
                }
                DB_CACHE['anonymous_tx'][tx.ID].append(receive_tx)
                # level_db.put_anonymous_tx_by_id(tx.ID, receive_tx)
            else:   # 明文地址交易
                vin = tx.Vin[0]
                from_address = vin.address

                send_tx = {
                    "type": "send",
                    "tx_id": tx.ID,
                    "from": from_address,
                    "is_anonymous": False,
                    "timestamp": tx.timestamp
                }

                # 当前UTXO交易输出数组第一个元素表示输出对象
                vout_obj = tx.Vout[0]

                # UTXO格式规定，交易输出数组，第一个是交易输出对象，如果存在第二个，说明是找零
                send_tx["to"] = vout_obj.pub_key_hash
                send_tx["amount"] = vout_obj.value

                if from_address == vout_obj.pub_key_hash:
                    send_tx["type"] = "move"

                if from_address not in DB_CACHE['cleartext_tx'].keys():
                    DB_CACHE['cleartext_tx'][from_address] = []
                DB_CACHE['cleartext_tx'][from_address].append(send_tx)
                # level_db.put_cleartext_tx_by_addr(from_address, send_tx)

                receive_tx = {
                    "type": "receive",
                    "tx_id": tx.ID,
                    "from": from_address,
                    "to": vout_obj.pub_key_hash,
                    "amount": vout_obj.value,
                    "is_anonymous": False,
                    "timestamp": tx.timestamp
                }

                #  当输出和输入地址一样时，说明时type是move，已经在send_tx中保存
                if receive_tx["from"] != receive_tx["to"]:
                    if vout_obj.pub_key_hash not in DB_CACHE['cleartext_tx'].keys():
                        DB_CACHE['cleartext_tx'][vout_obj.pub_key_hash] = []
                    DB_CACHE['cleartext_tx'][vout_obj.pub_key_hash].append(receive_tx)
                    # level_db.put_cleartext_tx_by_addr(vout_obj.pub_key_hash, receive_tx)

        # 4.更新总交易数
        tx_num = level_db.get_transaction_num()
        total_num = int(tx_num) + 1
        DB_CACHE['tx_num'] = total_num
        # level_db.put_transaction_num(total_num)

        # 5.更新最新交易
        latest_tx = dict()
        latest_tx['id'] = tx.ID
        latest_tx['time'] = tx.timestamp
        if tx.is_coinbase():
            latest_tx['from'] = "coinbase"
            latest_tx['to'] = tx.Vout[0].pub_key_hash
        else:
            latest_tx['from'] = tx.Vin[0].address
            for vout in tx.Vout:
                if vout.pub_key_hash != latest_tx['from']:
                    latest_tx['to'] = vout.pub_key_hash
                    break
        DB_CACHE['latest_tx'] = latest_tx
        # level_db.update_latest_transactions(latest_tx)

        # 6.更新最近活动的账户
        addr = dict()
        if tx.is_coinbase():
            addr['address'] = tx.Vout[0].pub_key_hash
        else:
            addr['address'] = tx.Vin[0].address
        addr['time'] = tx.timestamp
        DB_CACHE['latest_account'] = addr
        # level_db.update_latest_tran_address(addr)

        # 7.更新apphash
        # level_db.update_app_hash()
    except Exception as e:
        is_delivered = False
        LOGGER.error("deliver exception:" + str(e))

    return is_delivered


def json_to_tx(tx):
    """
    将json格式的交易 转换成 transaction 对象
    :param tx:
    :return:
    """
    # 生成交易实例
    vins = []
    for vin in tx['Vin']:
        tx_in = TxInput(vin['tx_id'], vin['tx_output_index'], vin['signature'], vin['address'], vin['pub_key'])
        vins.append(tx_in)

    vouts = []
    for vout in tx['Vout']:
        shield_pkey = None
        value_encrypt = None
        if "shield_pkey" in vout.keys():
            shield_pkey = vout['shield_pkey']

        if "value_encrypt" in vout.keys():
            value_encrypt = vout['value_encrypt']

        tx_out = TxOutput(vout['value'], vout['pub_key_hash'], shield_pkey, value_encrypt)

        vouts.append(tx_out)

    transaction = Transaction(tx['ID'], vins, vouts, tx['prove_data'], tx['timestamp'])

    return transaction


def get_tx_by_address(address, level_db, priva=None, wallet=None):
    """
    获取地址相关交易
    :param address: 查询地址
    :param level_db:
    :param priva: 查询密钥
    :param wallet: 
    :return: 
    """
    address_txs = []
    # 获取明文地址相关交易
    address_txs_dict = level_db.get_cleartext_addr_tx_bucket()
    # 查询明文地址
    if address in address_txs_dict.keys():
        txs_list = address_txs_dict[address]
        address_txs.extend(txs_list)

    # 查询隐藏地址
    anonymous_txs_dict = level_db.get_anonymous_addr_tx_bucket()
    # 解析匿名地址dict， key是tx_id, value是这笔交易的输入和输出
    for tx_id in list(anonymous_txs_dict.keys()):
        tx_list = anonymous_txs_dict[tx_id]

        # 挖矿交易没有输入，只有一个交易输出
        if len(tx_list) == 1:
            mine_tx = tx_list[0]
            is_verify = wallet.verify_shield(priva, mine_tx["to"], mine_tx["shield_pkey"])
            if is_verify and is_verify == "OK":
                address_txs.append(mine_tx)
            continue

        tx_input_info = {"is_this_addr": False, "addr": None}  # 表示交易输入是否是当前地址
        tx_output_info = {"is_this_addr": False, "sum": 0, "addr": None}  # 保存交易输出
        tx_is_correct = True    # 标记该笔交易是否正确
        for tx_data in tx_list:
            # 交易中包含两个角色，一个是交易发送方，type为send，一个是交易接受方，type为receive
            if tx_data["type"] == "send":
                tx_input_info["timestamp"] = tx_data["timestamp"]

                f_tx_id = tx_data["from_tx_id"]
                f_tx_output_index = tx_data["from_tx_output_index"]

                # 通过交易id查询交易id
                # query_url = TM_URL + "/tx?hash=0x" + f_tx_id
                query_url = TM_URL + "/tri_block_tx?hash=0x" + f_tx_id

                resp = requests.get(query_url)
                resp = json.loads(resp.content.decode("utf-8"))

                if not resp['error']:
                    r_tx = resp["result"]["tx"]
                    r_tx = base64.b64decode(r_tx)
                    r_tx = r_tx.decode("utf-8")
                    r_tx = r_tx.replace("'", '"', -1)
                    r_tx = json.loads(r_tx)

                    tx_vout = r_tx["Vout"][f_tx_output_index]
                    is_verify = wallet.verify_shield(priva, tx_vout["pub_key_hash"], tx_vout["shield_pkey"])
                    if is_verify and is_verify == "OK":
                        tx_input_info["is_this_addr"] = True
                        tx_input_info["addr"] = tx_vout["pub_key_hash"]
                    else:
                        tx_input_info["is_this_addr"] = False
                        tx_input_info["addr"] = tx_vout["pub_key_hash"]
                else:   # 查询交易有错
                    tx_is_correct = False

            # 解析交易输出
            elif tx_data["type"] == "receive":
                if "content" in tx_data.keys():
                    vout_list = tx_data["content"]
                    # UTXO交易输出数组第一个元素是交易对象，所以只要判断第一个元素即可
                    vout_obj = vout_list[0]
                    is_verify = wallet.verify_shield(priva, vout_obj.pub_key_hash, vout_obj.shield_pkey)
                    if is_verify and is_verify == "OK":
                        tx_output_info["is_this_addr"] = True
                        tx_output_info["sum"] = vout_obj.value
                        tx_output_info["addr"] = vout_obj.pub_key_hash
                    else:
                        tx_output_info["is_this_addr"] = False
                        tx_output_info["sum"] = vout_obj.value
                        tx_output_info["addr"] = vout_obj.pub_key_hash

        if tx_is_correct is not True:
            continue

        if tx_input_info["addr"] and tx_output_info["addr"]:
            # 开始组装返回信息
            resp_dict = {
                "tx_id": tx_id,
                "is_anonymous": True,
                "from": tx_input_info["addr"],
                "to": tx_output_info["addr"],
                "amount": tx_output_info["sum"],
                "timestamp": tx_input_info["timestamp"]
            }

            # 交易输出和交易输出一样，表示自己给自己转账
            if tx_input_info["is_this_addr"] is True and tx_output_info["is_this_addr"] is True:
                resp_dict["type"] = "move"
                address_txs.append(resp_dict)
            # 交易入地址是当前地址，输出地址不是当前地址，说明是当前地址向其他地址转账
            elif tx_input_info["is_this_addr"] is True and tx_output_info["is_this_addr"] is False:
                resp_dict["type"] = "send"
                address_txs.append(resp_dict)
            # 交易输入地址不是当前地址，输出地址是当前地址，说明是其余地址向当前地址转账
            elif tx_input_info["is_this_addr"] is False and tx_output_info["is_this_addr"] is True:
                resp_dict["type"] = "receive"
                address_txs.append(resp_dict)

    return address_txs
