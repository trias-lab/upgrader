#!/usr/bin/env python
# -*- coding:utf-8 -*-
import hashlib
import json
import time

from .txinput import TxInput
from .txoutput import TxOutput
from logs.tx_log import LOGGER


class Transaction:
    """
    交易
    # todo
    """

    def __init__(self, ID, vin, vout, prove_data="", timestamp=""):
        """
        :param ID:  交易id，交易的hash值
        :param vin:  vin 所有的交易输入， 数组
        :param vout:  vout 所有的交易输出， 数组
        :param prove_data:  证明输入和输出相等的证明数据
        :param timestamp:  交易时间戳
        """
        self.ID = ID
        self.Vin = vin
        self.Vout = vout
        self.prove_data = prove_data
        if timestamp:
            self.timestamp = timestamp
        else:
            self.timestamp = int(round(time.time() * 1000))

    def is_coinbase(self):
        """
        判断是否为coinbase（挖矿奖励）， coinbase没有交易输入
        :return:
        """
        is_base = False
        try:
            is_base = len(self.Vin) == 1 and len(self.Vin[0].tx_id) == 0 and self.Vin[0].tx_output_index == -1
        except Exception as e:
            LOGGER.error(e)
        return is_base

    def serialize(self):
        """
        序列化所有交易
        """
        vins = []
        vouts = []
        try:
            for vin in self.Vin:
                k = dict()
                k['tx_id'] = vin.tx_id
                k['tx_output_index'] = vin.tx_output_index
                k['signature'] = vin.signature
                k['address'] = vin.address
                k['pub_key'] = vin.pub_key

                vins.append(k)

            for vout in self.Vout:
                k = dict()
                k['value'] = vout.value
                k['shield_pkey'] = vout.shield_pkey
                k['pub_key_hash'] = vout.pub_key_hash
                k['value_encrypt'] = vout.value_encrypt
                vouts.append(k)
        except Exception as e:
            LOGGER.error(e)

        data = {
            "ID": self.ID,
            "Vin": vins,
            "Vout": vouts,
            "prove_data": self.prove_data,
            "timestamp": self.timestamp
        }

        return json.dumps(data, sort_keys=True)

    def hash(self):
        """
        计算交易的hash值,并将该值赋值给交易id
        :return:
        """
        # tx_hash = hashlib.sha256(self.serialize().encode('utf-8')).hexdigest()
        tx_hash = ""
        try:
            tx_hash = hashlib.new('ripemd160', self.serialize().encode('utf-8')).hexdigest().upper()
            self.ID = tx_hash
        except Exception as e:
            LOGGER.error(e)
        return tx_hash

    def trimmed_copy(self):
        """
        复制交易  用于签名和验证
        :return:
        """
        tx_inputs = []
        tx_outputs = []
        try:
            for vin in self.Vin:
                tx_in = TxInput(vin.tx_id, vin.tx_output_index, "",  "", "")
                tx_inputs.append(tx_in)

            for vout in self.Vout:
                tx_out = TxOutput(vout.value, vout.pub_key_hash, vout.shield_pkey, vout.value_encrypt)
                tx_outputs.append(tx_out)
        except Exception as e:
            LOGGER.error(e)

        tx_copy = Transaction(self.ID, tx_inputs, tx_outputs, self.prove_data, self.timestamp)
        return tx_copy

    def sign(self, address, prev_tx_dict, wallet):
        """
        签名  新建交易时调用
        :param address: 交易地址
        :param prev_tx_dict:
        :param wallet:  钱包
        :return:
        """
        if self.is_coinbase():
            return

        for tmp_vin in self.Vin:
            if tmp_vin.tx_id not in prev_tx_dict.keys():
                raise ValueError("ERROR: can not find the transaction.")

        # 复制交易
        tx_copy = self.trimmed_copy()
        # 为了数据确定性，如下数据数据需要被签名：
        # 1. 新的交易输出中的交易值
        # 2. 新的交易输出中的pub_key_hash 表示交易接受方
        # 3. 交易输入中的输出地址，交易的发送方
        for index, vin in enumerate(tx_copy.Vin):
            prev_tx = prev_tx_dict[vin.tx_id]
            prev_tx_out = prev_tx.Vout[vin.tx_output_index]

            tx_copy.Vin[index].signature = ""
            tx_copy.Vin[index].pub_key = ""
            # 指定交易的来源
            tx_copy.Vin[index].address = prev_tx_out.pub_key_hash

            # 交易id就是用来签名的数据
            tx_copy.hash()
            tx_copy.Vin[index].address = ""

            # 签名
            sign_resp = wallet.sign(address, tx_copy.ID, "1234qwer")

            if sign_resp['Pubkey'] and sign_resp['Sigadata']:
                self.Vin[index].pub_key = sign_resp['Pubkey']
                self.Vin[index].signature = sign_resp['Sigadata']
            else:
                raise Exception("sign failed.")

    def verify(self, prev_tx_dict, wallet):
        """
        验证交易  出块时调用该方法验证
        :param prev_tx_dict:
        :param wallet:
        :return:
        """
        result = False

        if self.is_coinbase():
            return True

        for tmp_vin in self.Vin:
            if tmp_vin.tx_id not in prev_tx_dict.keys():
                raise ValueError("ERROR: can not find the transaction.")

        # TODO 暂时注释签名验证
        """
        # 复制交易
        tx_copy = self.trimmed_copy()
        try:
            tmp_result = True

            for index, vin in enumerate(tx_copy.Vin):
                prev_tx = prev_tx_dict[vin.tx_id]
                prev_tx_out = prev_tx.Vout[vin.tx_output_index]

                tx_copy.Vin[index].signature = ""
                tx_copy.Vin[index].pub_key = ""

                tx_copy.Vin[index].address = prev_tx_out.pub_key_hash
                # 计算hash同时赋值给ID
                tx_copy.hash()

                tx_copy.Vin[index].address = ""

                # 获取签名
                sig = self.Vin[index].signature
                pub_key = self.Vin[index].pub_key

                verify_res = wallet.verify(pub_key, tx_copy.ID, sig)
                if verify_res == "OK":
                    is_valid = True
                else:
                    is_valid = False

                tmp_result = tmp_result and is_valid
                if not is_valid:
                    break

            result = tmp_result
        except Exception as e:
            LOGGER.error(e)
        """
        # TODO 暂时将签名验证去除
        result = True

        return result
