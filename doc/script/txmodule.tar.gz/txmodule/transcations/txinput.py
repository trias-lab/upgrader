#!/usr/bin/env python
# -*- coding:utf-8 -*-

from utils.hash_ripemd import hash_pub_key


class TxInput:
    """
    交易输入
    """

    def __init__(self, tx_id, tx_output_index, signature, address="", pub_key=""):
        self.tx_id = tx_id  # 交易id
        self.tx_output_index = tx_output_index  # 交易输出索引
        self.signature = signature  # 签名
        self.address = address  # 账号地址(自己的地址)
        self.pub_key = pub_key  # 公钥(创建交易时为空)

    def uses_address(self, address):
        """
        检查输出地址
        :param address:
        :return:
        """
        #TODO  加入地址以后会修改
        #pk_hash = hash_pub_key(self.pub_key)
        #return pk_hash == pub_key_hash

        return self.pub_key == address
