#!/usr/bin/env python
# -*- coding:utf-8 -*-
import json
import base64
import requests

from storage.leveldb_utils import DB_CACHE
from config.config import TM_URL
from .transaction import Transaction, TxInput, TxOutput
from logs.tx_log import LOGGER


# 单例
def singleton(cls):
    instances = {}

    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]

    return get_instance


@singleton
class UTXOSet:
    """
    UTXO交易池
    """
    def __init__(self, db):
        self.db = db

    def find_spendable_outputs(self, pub_key_hash, amount, priva=None, wallet=None):
        """
        查询足够amount的交易输出  new_utxo_transaction方法中使用
        :param pub_key_hash:
        :param amount:
        :param priva:
        :param wallet:
        :return:
        """
        accumulated = 0
        unspent_outs = {}  # key为txid， value是交易输出索引的数组
        unspent_txs = self.db.get_utxoset_bucket()

        for tx_id in unspent_txs:
            utxos = unspent_txs[tx_id]

            for index in utxos:
                tx_out = utxos[index]

                # 目前该接口只提供普通交易， 所以只处理交易输出中value是数字的情况
                if not isinstance(tx_out.value, (int, float)):
                    continue

                if tx_out.shield_pkey:
                    if priva:
                        is_current_addr = wallet.verify_shield(priva, tx_out.pub_key_hash, tx_out.shield_pkey)
                    else:
                        is_current_addr = False
                else:
                    is_current_addr = tx_out.is_locked_with(pub_key_hash)

                if is_current_addr and accumulated < int(amount):
                    accumulated = accumulated + tx_out.value

                    if tx_id not in unspent_outs:
                        unspent_outs[tx_id] = []

                    unspent_outs[tx_id].append(index)

                    if accumulated > int(amount):
                        break
            else:
                continue
            break

        return accumulated, unspent_outs

    def find_all_spendable_outputs(self, pub_key_hash, priva=None, wallet=None):
        """
        查询足够amount的交易输出  new_utxo_transaction方法中使用
        :param pub_key_hash:
        :param priva:
        :param wallet:
        :return:
        """
        unspent_outs = {}  # example: {tx_id:{index:1, amount:20}}
        unspent_txs = self.db.get_utxoset_bucket()

        for tx_id in unspent_txs:
            utxos = unspent_txs[tx_id]

            for index in utxos:
                tx_out = utxos[index]

                if tx_out.shield_pkey:
                    if priva:
                        is_verify = wallet.verify_shield(priva, tx_out.pub_key_hash, tx_out.shield_pkey)
                        if is_verify and is_verify == "OK":
                            is_current_addr = True
                        else:
                            is_current_addr = False
                    else:
                        is_current_addr = False
                else:
                    is_current_addr = tx_out.is_locked_with(pub_key_hash)

                if is_current_addr:

                    if tx_id not in unspent_outs:
                        unspent_outs[tx_id] = []

                    tx_out_dict = {"index": index, "value": tx_out.value, "shield_pkey": tx_out.shield_pkey, "addr": tx_out.pub_key_hash, "value_encrypt": tx_out.value_encrypt}
                    unspent_outs[tx_id].append(tx_out_dict)

        return unspent_outs

    def find_utxos_by_txid(self, tx_id):
        """
        通过交易id查询utxos  check_tx方法使用
        :param tx_id:
        :return:
        """
        unspent_outs = []  # key为txid， value是交易输出索引的数组
        unspent_txs = self.db.get_utxoset_bucket()

        for tran_id in unspent_txs:
            if tran_id == tx_id:
                for out_index in unspent_txs[tx_id].keys():
                    unspent_outs.append(out_index)
        return unspent_outs

    def find_utxos_by_address(self, pub_key_hash, priva=None, wallet=None):
        """
        查找地址对应的utxo   get_balance方法使用
        :param pub_key_hash:
        :param priva:
        :param wallet:
        :return:
        """
        unspent_outs = {"normal": [], "crypto": []}
        unspent_txs = self.db.get_utxoset_bucket()

        for tx_id in list(unspent_txs.keys()):
            for tx_out in unspent_txs[tx_id].values():
                if tx_out.shield_pkey is not None and tx_out.shield_pkey.strip() != "":
                    if priva is not None:
                        is_verify = wallet.verify_shield(priva, tx_out.pub_key_hash, tx_out.shield_pkey)
                        if is_verify and is_verify == "OK":
                            unspent_outs["crypto"].append(tx_out)
                else:
                    if tx_out.is_locked_with(pub_key_hash):
                        unspent_outs["normal"].append(tx_out)

        return unspent_outs

    def update_utxo_by_tx(self, tx):
        """
        更新UTXO池
        :param tx:
        :return:
        """
        result = False

        try:
            if not tx.is_coinbase():
                for tx_input in tx.Vin:
                    # 保存余下未被使用的交易输出
                    remainder_utxos = {}
                    tx_id = tx_input.tx_id
                    # 获取交易id相关的utxo 如果交易id相关的所有utxo都使用了 直接删除
                    # 如果还有剩余未使用的utxo直接更新 utxoset[tx_id] = 剩余utxo 这样会覆盖之前的记录
                    utxos = self.db.get_utox_by_txid(tx_id)
                    if not utxos:
                        continue

                    for index in utxos.keys():
                        if index != tx_input.tx_output_index:
                            remainder_utxos[index] = utxos[index]

                    # 如果没有剩余，删除相关utxo
                    if not remainder_utxos:
                        DB_CACHE['utxo_del'].append(tx_id)
                        # self.db.del_utxo_by_txid(tx_id)
                    else:
                        DB_CACHE['utxo_add'][tx_id] = remainder_utxos
                        # self.db.put_utxos(tx_id, remainder_utxos)

            # 新的交易保存到utxo池中
            new_utxos = {}
            for index, vout in enumerate(tx.Vout):
                new_utxos[index] = vout

            if new_utxos:
                DB_CACHE['utxo_add'][tx.ID] = new_utxos
                # self.db.put_utxos(tx.ID, new_utxos)

            result = True
        except Exception as e:
            LOGGER.error(e)
        return result

    def update_utxo(self, block):
        """
        更新UTXO池
        当有新块时，需要做两件事
        1.从utxo池中删除已消费的
        2.添加新未花费的
        :param block:
        :return:
        """
        if not block:
            return "block cannot be empty."

        txs = block["data"]["txs"]

        for tx in txs:
            tx = base64.b64decode(tx)
            tx = json.loads(tx.decode("utf-8").replace("'", '"', -1))
            # 将交易实例化
            vins = []
            for vin in tx['Vin']:
                t_input = TxInput(vin['tx_id'], vin['tx_output_index'], vin['signature'], vin['address'], vin['pub_key'])
                vins.append(t_input)

            vouts = []
            for vout in tx['Vout']:
                t_out = TxOutput(vout['value'], vout['pub_key_hash'])
                vouts.append(t_out)

            tx = Transaction(tx['ID'], vins, vouts, tx['prove_data'], tx['timestamp'])
            if not tx.is_coinbase():
                for tx_input in tx.Vin:
                    # 余下未被使用的交易输出
                    remainder_utxos = {}
                    tx_id = tx_input.tx_id

                    utxos = self.db.get_utox_by_txid(tx_id)
                    if not utxos:
                        continue

                    for index in utxos.keys():
                        if index != tx_input.tx_output_index:
                            remainder_utxos[index] = utxos[index]

                    # 如果没有剩余，删除相关utxo
                    if not remainder_utxos:
                        self.db.del_utxo_by_txid(tx_id)
                    else:
                        self.db.put_utxos(tx_id, remainder_utxos)

            # 新的交易保存到utxo池中
            new_utxos = {}
            for index, vout in enumerate(tx.Vout):
                new_utxos[index] = vout
            if new_utxos:
                self.db.put_utxos(tx.ID, new_utxos)

    def update_state(self):
        """
        每次启动 更新本机状态
        :return:
        """
        # 向tm查询区块高度，如果高于本地的高度 则需要查询块更新
        query_url = TM_URL + "/status"
        resp = requests.get(query_url)
        resp = json.loads(resp.content.decode("utf-8"))
        latest_block_height = resp["result"]["latest_block_height"]

        local_height = self.db.get_height()
        while latest_block_height > local_height:
            local_height = local_height + 1
            # 遍历块
            block_url = TM_URL + "/block?height=" + str(local_height)
            resp = requests.get(block_url)
            resp = json.loads(resp.content.decode("utf-8"))
            result = resp["result"]
            if result:
                block = result["block"]
                # 更新状态
                self.update_utxo(block)
        """
        # 先清空CHAINSTATE
        self.db.clear_chainstate()
        # 再更新chainstate
        utxos = find_all_utxos()
        for tx_id in utxos:
            self.db.put_utxos(tx_id, utxos[tx_id])
        """
