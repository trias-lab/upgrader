#!/usr/bin/env python
# -*- coding:utf-8 -*-

import json
import socket
import random
import threading

from logs.tx_log import LOGGER


# 创建请求锁
rpc_call_lock = threading.Lock()


class AccountRPC(object):
    def __init__(self, addr, codec=json):
        self._socket = socket.create_connection(addr)
        self._codec = codec

    def _message(self, name, *params):
        return dict(id=random.randint(1, 1000),
                    params=list(params),
                    method=name)

    def call(self, name, *params):
        result = None
        try:
            rpc_call_lock.acquire()

            req = self._message(name, *params)
            req_id = req.get('id')

            mesg = self._codec.dumps(req)
            self._socket.sendall(bytes(mesg, encoding='utf-8'))

            # This will actually have to loop if resp is bigger
            resp = self._socket.recv(4096)
            resp = self._codec.loads(resp.decode(encoding="utf-8"))

            if resp.get('id') != req_id:
                raise Exception("expected id=%s, received id=%s: %s"
                                % (req_id, resp.get('id'), resp.get('error')))

            if resp.get('error') is not None:
                raise Exception(resp.get('error'))

            result = resp.get('result')
        except Exception as e:
            LOGGER.error(e)
        finally:
            rpc_call_lock.release()

        return result

    def close(self):
        self._socket.close()


if __name__ == '__main__':
    rpc = AccountRPC(("127.0.0.1", 9876))

    a = 'b4452ed40100856ff151526de1e35f7049d07d6a3e6869613236006f15fc77061cbe1f9c029eb2a635c174d64373ca8c'
    b = 'ef9c9f9f7597c711d790b052f5b9c0adb556781d7386fd2f8153b43055bf9497'
    c = '91e1015e993ee4e5098123bc65e21c9ea3a189f41b0e21682df5817646c09347e1ea00d61b2acd846d1828b56155826af884914305fe08c1d883eabe8d0619be'
    print("AccRPC.Verify_shield2 ==",
             rpc.call("AccRPC.Verify_shield2", {"priva": a, "shieldaddr": b, "shieldpkey": c}))


    print("AccRPC.JsonTest", rpc.call("AccRPC.JsonTest", {"name": "Trias", "age": 24}))
    print("AccRPC.Test", rpc.call("AccRPC.Test", "The test is ok"))
    print("==========================")

    #print("AccRPC.CreateAcc",rpc.call("AccRPC.CreateAcc", {"path":"/tmp/testacc.json","pass":"1234qwer"}))
    print("AccRPC.ImportAcc", rpc.call("AccRPC.ImportAcc", {"path": "/tmp/testacc.json", "pass": "1234qwer"}))
    acclist = rpc.call("AccRPC.GetAcclist", "GetAcclist")
    print("AccRPC.GetAcclist", acclist)

    tsign = rpc.call("AccRPC.Sign", {"addr": acclist[0], "hash": "hashtext", "pass": "1234qwer"})
    print("AccRPC.Sign", tsign)
    print("AccRPC.Verify",
          rpc.call("AccRPC.Verify", {"pubkey": tsign['Pubkey'], "hash": "hashtext", "stext": tsign['Sigadata']}))

    cs = rpc.call("AccRPC.CreateShieldAddr", acclist[0])
    print("AccRPC.CreateShieldAddr", cs)
    print("AccRPC.Verify_shield", rpc.call("AccRPC.Verify_shield", {"addr": acclist[0], "shieldaddr": cs['Shieldaddr'],
                                                                    "shieldpkey": cs['ShieldpKey']}))
    stsign = rpc.call("AccRPC.Shield_Sign",
                      {"addr": acclist[0], "pass": "1234qwer", "hash": "hashtext", "shieldpkey": cs['ShieldpKey']})
    print("AccRPC.Shield_Sign", stsign)
    print("AccRPC.Verify",
          rpc.call("AccRPC.Verify", {"pubkey": stsign['Pubkey'], "hash": "hashtext", "stext": stsign['Sigadata']}))

    print("AccRPC.Pubkey2Addr", rpc.call("AccRPC.Pubkey2Addr", tsign['Pubkey']))
