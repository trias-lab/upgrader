# -*- coding: utf-8 -*-
import socket


def get_host_ip():
    """
    查询本机ip地址
    :return: ip
    """
    new_socket = None
    ip = None
    try:
        new_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        new_socket.connect(('8.8.8.8', 80))
        ip = new_socket.getsockname()[0]
    except Exception as e:
        print(e)
    finally:
        if new_socket:
            new_socket.close()
    return ip
