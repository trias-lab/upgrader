#!/usr/bin/env python
# -*- coding:utf-8 -*-
import os
import json
import requests
import hashlib
import binascii
import copy

from datetime import datetime
from flask import Flask, request, jsonify, make_response

from logs.tx_log import LOGGER
from wallet.wallet import Wallet
from config.config import TM_URL
from transcations.utxo_set import UTXOSet
from storage.leveldb_utils import LeveldbUtils, DB_CACHE
from transcations.tx_cli import get_balance, new_coinbase_tx, new_utxo_transaction, json_to_tx, sign_tx, check_tx, \
    deliver_tx, get_tx_by_address

app = Flask(__name__)

_app_root_path = app.root_path
_level_db_dir = _app_root_path + os.path.sep + "data"
_account_file = _app_root_path + os.path.sep + "wallet" + os.path.sep + "account.json"

# 初始化钱包
_wallet = Wallet(_account_file)
# 初始化leveldb
_level_db = LeveldbUtils(_level_db_dir)
# 初始化UTXO
_utxo_set = UTXOSet(_level_db)


@app.route('/')
def hello_world():
    return 'Welcome to www.trias.one'


@app.route('/new_utxo_transaction', methods=['POST'])
def new_utxo_transaction0():
    result = {'code': 'failure',
              'msg': ''}

    try:
        from_address = request.form["from_address"]
        to_address = request.form["to_address"]
        amount = request.form["amount"]
        # 新建交易
        new_utxo_response = new_utxo_transaction(from_address, to_address, amount, _utxo_set)

        if new_utxo_response['tx']:
            trans = new_utxo_response['tx']

            # 签名
            is_signed = sign_tx(trans, from_address, _wallet)

            if is_signed:
                trans = trans.serialize().replace('"', "'", -1)
                result['code'] = "success"
                result['content'] = trans

                # 发送交易给tm
                tx_url = TM_URL + "/tri_bc_tx_async?tx=\"" + trans + "\""
                # tx_url = TM_URL + "/broadcast_tx_async?tx=\"" + trans + "\""

                resp = requests.get(tx_url)
                resp = json.loads(resp.content.decode("utf-8"))
                if not resp["error"]:
                    result['code'] = "success"

            else:
                result['msg'] = "sign failed."
        else:
            result['code'] = "failure"
            result['msg'] = new_utxo_response['msg']
    except Exception as e:
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/get_utxo_transaction', methods=['POST'])
def get_utxo_transaction0():
    result = {'code': 'failure',
              'msg': ''}

    try:
        from_address = request.form["from_address"]
        to_address = request.form["to_address"]
        amount = request.form["amount"]
        # 新建交易
        new_utxo_response = new_utxo_transaction(from_address, to_address, amount, _utxo_set)

        if new_utxo_response['tx']:
            trans = new_utxo_response['tx']

            # 签名
            is_signed = sign_tx(trans, from_address, _wallet)

            if is_signed:
                trans = trans.serialize().replace('"', "'", -1)
                result['code'] = "success"
                result['content'] = trans
            else:
                result['msg'] = "sign failed."
        else:
            result['code'] = "failure"
            result['msg'] = new_utxo_response['msg']
    except Exception as e:
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/broadcast_tx', methods=['POST'])
def broadcast_tx():
    result = {'code': 'failure',
              'msg': ''}
    try:
        tx = request.form['tx']

        # 发送交易给tm
        tx_url = TM_URL + "/tri_bc_tx_async?tx=\"" + tx + "\""
        # tx_url = TM_URL + "/broadcast_tx_async?tx=\"" + tx + "\""

        resp = requests.get(tx_url)
        resp = json.loads(resp.content.decode("utf-8"))
        if not resp["error"]:
            result['code'] = "success"
        else:
            result['msg'] = resp['error']
    except Exception as e:
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/new_coinbase_tx', methods=['POST'])
def new_coinbase_tx0():
    result = {'code': 'failure'}
    try:
        to_address = request.form["to_address"]

        trans = new_coinbase_tx(to_address)
        if trans:
            trans = trans.serialize().replace('"', "'", -1)
            result['content'] = trans

            # 发送交易给tm
            tx_url = TM_URL + "/tri_bc_tx_async?tx=\"" + trans + "\""
            # tx_url = TM_URL + "/broadcast_tx_async?tx=\"" + trans + "\""

            resp = requests.get(tx_url)
            resp = json.loads(resp.content.decode("utf-8"))
            if not resp["error"]:
                result['code'] = "success"
            else:
                result['msg'] = resp["error"]
        else:
            result['msg'] = "new transaction failed."
    except Exception as e:
        result['msg'] = e
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/get_balance', methods=['GET'])
def get_balance0():
    result = {'balance': 0,  # 明文地址交易余额
              'balance_hide_amount': [],  # 明文地址隐藏金额交易余额
              'crypto_balance': 0,  # 隐私地址交易余额
              'crypto_balance_hide_amount': []  # 隐私地址隐藏金额交易余额
              }
    try:
        address = request.args.get('address', None)
        priva = request.args.get('priva', None)  # 查询账户密钥

        if priva and priva != "undefined":
            balance, balance_hide_amount, crypto_balance, crypto_balance_hide_amount = get_balance(address, _utxo_set, priva, _wallet)
        else:
            balance, balance_hide_amount, crypto_balance, crypto_balance_hide_amount = get_balance(address, _utxo_set)
        result['code'] = "success"
        result['balance'] = balance
        result['balance_hide_amount'] = balance_hide_amount
        result['crypto_balance'] = crypto_balance
        result['crypto_balance_hide_amount'] = crypto_balance_hide_amount
    except Exception as e:
        result['code'] = "failure"
        result['msg'] = str(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/check_tx', methods=['POST'])
def check_tx0():
    result = "failure"
    try:
        tx = request.form["tx"]
        tx = tx.replace("'", '"', -1)

        tx = json.loads(tx)
        tx = json_to_tx(tx)
        # 验证交易
        is_verified = check_tx(tx, _wallet)

        if is_verified:
            result = "success"
    except Exception as e:
        LOGGER.error(e)

    return result


@app.route('/begin_block', methods=['GET'])
def begin_block():
    # 开始出块 初始化level缓存
    DB_CACHE.clear()
    # UTXO相关缓存
    DB_CACHE['utxo_del'] = []   # tx_id数组
    DB_CACHE['utxo_add'] = {}   # key:tx_id, value: utxo {value:xxx, out:xxxx}
    # 隐私地址和明文地址相关交易缓存
    DB_CACHE['anonymous_tx'] = {}   # 匿名地址
    DB_CACHE['cleartext_tx'] = {}   # 明文地址  {"tx_addr": {交易内容} ... }
    # 总交易数缓存
    DB_CACHE['tx_num'] = None
    # 最新交易缓存
    DB_CACHE['latest_tx'] = None
    # 最新活动账户
    DB_CACHE['latest_account'] = None

    # 打印出时apphash
    # init_app_hash = _level_db.get_app_hash()
    # LOGGER.error("!!!! init app hash: " + str(init_app_hash))

    return "begin block"


@app.route('/deliver_tx', methods=['POST'])
def deliver_tx0():
    result = "failure"
    try:
        tx = request.form["tx"]
        tx = tx.replace("'", '"', -1)
        tx = json.loads(tx)
        tx = json_to_tx(tx)
        # 执行交易并更新本地状态
        is_delivered = deliver_tx(tx, _utxo_set, _level_db)
        if is_delivered:
            result = "success"
    except Exception as e:
        LOGGER.error("deliver error:" + str(e))
    return result


@app.route('/end_block', methods=['GET'])
def end_block():
    return "EndBlock"


@app.route('/commit_tx', methods=['GET'])
def commit_tx():
    start_time = datetime.now()

    new_app_hash = _level_db.get_app_hash()
    try:
        add_utxos = {}  # 保存转变格式以后的utxo 用于计算app hash
        anonymous_tx_format = {}    # 用于保存格式化的anonymous_tx 计算app hash

        # 深度copy utxo记录  由于utxo时字典 如果不深度copy 改变其中的值会影响本地保存的值
        if DB_CACHE["utxo_del"] or DB_CACHE['utxo_add']:
            tmp_utxos = copy.deepcopy(_level_db.get_utxoset_bucket())
        else:
            tmp_utxos = {}

        tmp_anonymous_tx = {}
        tmp_cleartext_tx = {}

        # 解析缓存
        for key, value in DB_CACHE.items():
            if key == "utxo_del":   # 需要删除的utxo
                for item in value:
                    tmp_utxos.pop(item, "the key " + item + " not exist.")
                    # _level_db.del_utxo_by_txid(item)
            elif key == "utxo_add":  # 需要添加的utxo
                for t_key, t_value in value.items():
                    # 格式化txoutput 否则json报错
                    tmp_dict = {}
                    for tmp_key, tmp_value in t_value.items():
                        tmp_dict[tmp_key] = tmp_value.__dict__
                    add_utxos[t_key] = tmp_dict

                    tmp_utxos[t_key] = t_value
                    # _level_db.put_utxos(t_key, t_value)
            elif key == "anonymous_tx":  # 匿名地址相关的交易
                if DB_CACHE['anonymous_tx']:
                    tmp_anonymous_tx = copy.deepcopy(_level_db.get_anonymous_addr_tx_bucket())

                for t_key, tt_value in value.items():
                    for t_value in tt_value:
                        # 当这笔交易非隐私地址挖矿交易时 进行格式化操作  只有隐私地址非挖坑交易才有content  key
                        if t_value['type'] == "receive" and "content" in t_value.keys():
                            # 格式化交易content中的txoutput 负责json时报错
                            content_format = []
                            for tmp_txoutput in t_value['content']:
                                content_format.append(tmp_txoutput.__dict__)
                            anonymous_tx_format[t_key] = {
                                "type": t_value['type'],
                                "content": content_format,
                                "timestamp": t_value['timestamp']
                            }
                        else:
                            anonymous_tx_format[t_key] = t_value

                    # 更新缓存 最后一起更新
                    if t_key not in tmp_anonymous_tx.keys():
                        tmp_anonymous_tx[t_key] = []
                    tmp_anonymous_tx[t_key].extend(tt_value)
                    # 写入本地leveldb
                    # _level_db.put_anonymous_tx_by_id(t_key, t_value)
            elif key == "cleartext_tx":  # 明文地址相关的交易
                if DB_CACHE['cleartext_tx']:
                    tmp_cleartext_tx = copy.deepcopy(_level_db.get_cleartext_addr_tx_bucket())

                for t_key, t_value in value.items():
                    if t_key not in tmp_cleartext_tx.keys():
                        tmp_cleartext_tx[t_key] = []
                    tmp_cleartext_tx[t_key].extend(t_value)
                    # _level_db.put_cleartext_tx_by_addr(t_key, t_value)
            elif key == "tx_num" and DB_CACHE['tx_num'] is not None:  # 交易总数
                _level_db.put_transaction_num(value)
            elif key == "latest_tx" and DB_CACHE['latest_tx'] is not None:  # 最新交易
                _level_db.update_latest_transactions(value)
            elif key == "latest_account" and DB_CACHE['latest_account'] is not None:  # 最近活动账户
                _level_db.update_latest_tran_address(value)

        # 更新本地leveldb
        if tmp_utxos:
            _level_db.update_utxoset_bucket(tmp_utxos)

        if tmp_anonymous_tx:
            _level_db.update_anonymous_addr_tx_bucket(tmp_anonymous_tx)

        if tmp_cleartext_tx:
            _level_db.update_cleartext_addr_tx_bucket(tmp_cleartext_tx)

        # 开始更新app_hash
        if anonymous_tx_format:
            DB_CACHE["anonymous_tx"] = anonymous_tx_format

        for add_key, add_value in add_utxos.items():
            DB_CACHE["utxo_add"][add_key] = add_value

        if add_utxos:
            # 1.初始化hash
            hash_method = hashlib.sha1()
            hash_method.update(new_app_hash.encode("utf-8"))
            # 2.叠加最新hash
            cache_byte = json.dumps(DB_CACHE, sort_keys=True).encode('utf-8')
            cache_hash = hashlib.new('ripemd160', cache_byte).hexdigest()
            hash_method.update(bytes.fromhex(cache_hash))

            # 重新计apphash值
            calc_app_hash = hash_method.digest()
            new_app_hash = bytes.decode(binascii.hexlify(calc_app_hash))

        # 更新apphash到本地leveldb
        _level_db.put_app_hash(new_app_hash)

        end_time = datetime.now()
        use_seconds = (end_time - start_time).seconds
        LOGGER.error("commit execution time: " + str(use_seconds) + " seconds")
    except Exception as e:
        LOGGER.error(e)
    finally:
        DB_CACHE.clear()

    return new_app_hash


@app.route('/get_block_by_height', methods=['GET'])
def get_block_by_height():
    result = {'code': 'failure',
              'msg': '',
              'content': None}
    try:
        height = request.args.get('height', None)
        block_url = TM_URL + "/tri_block_info?height=" + str(height)
        resp = requests.get(block_url)
        resp = json.loads(resp.content.decode("utf-8"))
        if not resp["error"]:
            result['content'] = resp['result']
            result['code'] = "success"
        else:
            result['msg'] = resp['error']
    except Exception as e:
        result['msg'] = e
        LOGGER.error(e)

    return jsonify(result)


@app.route('/get_latest_block_height', methods=['GET'])
def get_latest_block_height():
    result = {"height": 0}
    tx_url = TM_URL + "/tri_abci_info"
    resp = requests.get(tx_url)
    resp = json.loads(resp.content.decode("utf-8"))
    height = resp['result']['response']['last_block_height']
    result['latest_block_height'] = height
    return jsonify(result)


@app.route('/get_address_num', methods=['GET'])
def get_address_num():
    # 获取所有涉及过交易的地址总和，即有过交易记录的地址的总和
    result = {'address_num': 0}
    num = len(_level_db.get_cleartext_addr_tx_bucket().keys())
    result['address_num'] = num
    return jsonify(result)


@app.route('/get_address_tx', methods=['GET'])
def get_address_tx0():
    # 获取地址相关的交易记录
    result = {"txs": []}
    try:
        address = request.args.get('address', None)
        priva = request.args.get('priva', None)

        if priva and priva != "undefined":
            txs = get_tx_by_address(address, _level_db, priva, _wallet)
        else:
            txs = get_tx_by_address(address, _level_db)

        result = {"txs": txs}
    except Exception as e:
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/get_transaction_num', methods=['GET'])
def get_transaction_num():
    result = {"transaction_num": 0}
    num = _level_db.get_transaction_num()
    result['transaction_num'] = num
    return jsonify(result)


@app.route('/get_latest_address', methods=['GET'])
def get_latest_address():
    result = {'addresses': []}
    addr = _level_db.get_latest_tran_address()
    for tmp_addr in addr:
        balance = get_balance(tmp_addr['address'], _utxo_set)
        tmp_addr['balance'] = balance[0]
        result['addresses'].append(tmp_addr)

    return jsonify(result)


@app.route('/get_latest_blocks', methods=['GET'])
def get_latest_blocks():
    tx_url = TM_URL + "/tri_abci_info"
    resp = requests.get(tx_url)
    resp = json.loads(resp.content.decode("utf-8"))
    max_height = resp['result']['response']['latest_block_height']
    if max_height - 10 >= 0:
        min_height = max_height - 10 + 1
    else:
        min_height = 1

    blockchain_url = TM_URL + "/tri_blockchain_interval?minHeight=" + str(min_height) + "&maxHeight=" + str(max_height)
    resp = requests.get(blockchain_url)
    resp = json.loads(resp.content.decode("utf-8"))

    return jsonify(resp)


@app.route('/get_latest_transactions', methods=['GET'])
def get_latest_transactions():
    result = {"transactions": []}
    txs = _level_db.get_latest_transactions()
    result['transactions'] = txs

    return jsonify(result)


@app.route('/find_spendable_outputs', methods=['GET'])
def find_spendable_outputs0():
    result = {
        'code': 'failure',
        'msg': '',
        'accumulated': 0,
        'unspent_outs': {}
    }

    from_address = request.args.get('from_address', None)
    amount = request.args.get('amount', None)
    priva = request.args.get('priva', None)  # 查询账户密钥

    try:
        if not priva:  # 查询地址是隐藏地址
            accumulated, unspent_outs = _utxo_set.find_spendable_outputs(from_address, amount, priva, _wallet)
        else:   # 查询地址是显式地址
            accumulated, unspent_outs = _utxo_set.find_spendable_outputs(from_address, amount)

        if int(accumulated) < int(amount):
            result['code'] = 'failure'
            result['msg'] = "not enough found."
        else:
            result['code'] = 'success'
            result['accumulated'] = accumulated
            result['unspent_outs'] = unspent_outs
    except Exception as e:
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/find_all_spendable_outputs', methods=['GET'])
def find_all_spendable_outputs():
    result = {
        'code': 'failure',
        'msg': '',
        'accumulated': 0,
        'unspent_outs': {}
    }

    from_address = request.args.get('from_address', None)
    priva = request.args.get('priva', None)  # 查询账户密钥

    try:
        if priva and priva != "undefined":  # 查询地址是隐藏地址
            unspent_outs = _utxo_set.find_all_spendable_outputs(from_address, priva, _wallet)
        else:   # 查询地址是显式地址
            unspent_outs = _utxo_set.find_all_spendable_outputs(from_address)

        result['code'] = 'success'
        result['unspent_outs'] = unspent_outs
    except Exception as e:
        LOGGER.error(e)

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


@app.route('/new_account', methods=['GET'])
def new_account():
    result = {'code': 'failure'}
    try:
        account = _wallet.new_account()
        result['account'] = account
        result['code'] = 'success'
    except Exception as e:
        LOGGER.error(e)

    return jsonify(result)


@app.route('/get_accounts', methods=['GET'])
def get_accounts():
    result = {'code': 'failure'}
    try:
        accounts = _wallet.get_account_list()
        result['accounts'] = accounts
        result['code'] = 'success'
    except Exception as e:
        LOGGER.error(e)

    return jsonify(result)


@app.route('/get_tx_by_hash', methods=['GET'])
def get_tx_by_hash():
    result = {'code': "failure",
              'msg': "",
              'content': None}
    try:
        tx_hash = request.args['hash']

        # tx_url = TM_URL + "/tx?hash=0x" + tx_hash
        tx_url = TM_URL + "/tri_block_tx?hash=0x" + tx_hash

        resp = requests.get(tx_url)
        resp = json.loads(resp.content.decode("utf-8"))

        if not resp['error']:
            result['code'] = "success"
            result['content'] = resp['result']
        else:
            result['msg'] = resp['error']
    except Exception as e:
        result['msg'] = e
        LOGGER.error(e)

    return jsonify(result)


@app.route('/get_prove_data', methods=['POST', 'OPTIONS'])
def get_prove_data():
    result = {'code': "failure",
              'msg': "",
              'content': None}
    try:
        if request.method == 'OPTIONS':
            response = make_response()
            response.headers['Access-Control-Allow-Origin'] = '*'
            response.headers["Access-Control-Allow-Headers"] = "content-type"
            response.headers["Access-Control-Request-Method"] = "POST"

            return response

        prove_data = request.data.decode("utf-8")
        if prove_data:
            resp = _wallet.get_prove_data(prove_data)
            result['code'] = "success"
            result['content'] = resp
    except Exception as e:
        result['msg'] = e

    response = make_response(jsonify(result))
    response.headers['Access-Control-Allow-Origin'] = '*'

    return response


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=9981, debug=False, threaded=True)
