# -*- coding: utf-8 -*-

import sys
import threading
import gflags
import requests
import json

from flask import Flask, request, jsonify

from handlers.result import response
from handlers.loop_timer import LoopTimer
from config.configs import DEFAULT_PORT, DAG_PORT
from handlers import msg_handler
from handlers.queue_handler import update_whitelist
from mylogger.trias_logger import LOGGER
from handlers.queue_handler import WHITELIST_QUEUE
from handlers.result import response as trias_response
from handlers.msg_handler import handle_distrustful_nodes, VERIFY_NODE_DICT, DISTRUSTFUL_NODES_DICT, clear_mem

FLAGS = gflags.FLAGS
gflags.DEFINE_integer('PORT', DEFAULT_PORT, 'port listening on', lower_bound=0)
# 标识是否时首次证实
IS_FIRST_ATTESTATION = True


app = Flask(__name__)


@app.route('/')
def hello_trias():
    return 'Hello Trias!'


@app.route('/trias/msghandle', methods=['POST'])
def msghandle():
    try:
        # request.form.get('node_ip')
        node_ip = request.form.get('node_ip', None)
        node_port = request.form.get('node_port', None)
        content = request.form.get('content', None)
        action = request.form.get('action', None)

        if not node_ip:
            result = trias_response('1', 'node_ip can not be null', None)
            return jsonify(result)

        action = int(action)

        if action == 1:  # 更新白名单
            if content:
                content = eval(content)  # 格式：[[file_path,file_hash], [file_path,file_hash]...]
                item = (node_ip, content)
                WHITELIST_QUEUE.put(item)

            msg = node_ip + " batch upadte white list successfully"
            LOGGER.info("[TRIAS_INFO]: " + msg)
            result = trias_response('1', msg, None)

            return jsonify(result)
        elif action == 2:  # 启动证实
            return jsonify(msg_handler.start_verify(node_ip, node_port))
        elif action == 3:  # 停止证实
            return jsonify(msg_handler.stop_verify(node_ip))
    except Exception as e:
        error_msg = str(e)
        LOGGER.error("[TRIAS_ERROR]: " + error_msg)
        result = trias_response('1', error_msg, None)
        return jsonify(result)


@app.route('/trias/getnodeinfo', methods=['GET'])
def get_node_info():
    # ima 行数
    ima_line = request.form.get('ima_line', None)
    # 判断时是否获取ima内容
    get_data = request.form.get('request_from', None)
    if get_data and ima_line and get_data == "verify":
        ima_line = int(ima_line)
        return jsonify(msg_handler.get_node_info(ima_line))
    else:
        resp = response('1', "success", None)
        return jsonify(resp)


@app.route('/trias/getverifynodes', methods=['GET'])
def get_verify_nodes():
    nodes = []
    for node in VERIFY_NODE_DICT.keys():
        nodes.append(node)
    return jsonify(nodes)


@app.route('/trias/getdistrustfulnodes', methods=['GET'])
def get_dis_nodes():
    return jsonify(DISTRUSTFUL_NODES_DICT)


@app.route('/trias/getimanum', methods=['GET'])
def get_ima_num():
    return jsonify(msg_handler.IMA_LINE_NUM)


@app.route('/trias/getranking', methods=['GET'])
def get_ranking():
    ranking = {"ranking": []}
    resp = None
    try:
        # 获取最新计算可信排名
        headers = {
            "Content-Type": "application/json",
            "Cache-Control": "no-cache"
        }

        data = {
            "period": -1,
            "numRank": 10
        }

        req_url = "http://127.0.0.1" + ":" + str(DAG_PORT) + "/QueryNodes"
        requests.adapters.DEFAULT_RETRIES = 1
        r_session = requests.session()
        r_session.keep_alive = False
        resp = r_session.post(req_url, headers=headers, data=json.dumps(data), timeout=(3, 9))

        resp_str = resp.content.decode("utf-8")
        resp_dict = json.loads(resp_str)
        if resp_dict["Code"] == 1:
            data_score = resp_dict["Data"]["DataScore"]
            ranking = data_score[:7]

        return jsonify(ranking)
    except Exception as e:
        error_msg = str(e)
        LOGGER.error("[TRIAS_ERROR]: " + error_msg)
        result = trias_response('1', error_msg, None)
        return jsonify(result)
    finally:
        if resp:
            resp.close()


if __name__ == '__main__':
    # 启动队列处理进程
    threading.Thread(target=update_whitelist).start()
    # 启动不可信节点事件监听进程
    threading.Thread(target=handle_distrustful_nodes).start()
    # 清理内存,5分钟清理一次
    LoopTimer(300, clear_mem).start()

    FLAGS(sys.argv)
    if FLAGS.PORT:
        print("listening on port %s" % FLAGS.PORT)
        app.run(host='0.0.0.0', port=FLAGS.PORT, debug=False, threaded=True)
        # app.run(host='0.0.0.0', port=FLAGS.PORT, debug=True)
    else:
        print('Please assign PORT.')
        exit()
