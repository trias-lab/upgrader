# -*- coding: utf-8 -*-
import os

if os.path.exists("/8lab"):
    if not os.path.exists("/8lab/attestation"):
        os.mkdir("/8lab/attestation")

WHITELIST_DB_DIR = "/8lab/attestation/whitelistdb"  # 白名单数据目录

DEFAULT_PORT = 8987  # 默认端口号
TM_PORT = 46657  # TM端口号
DAG_PORT = 8000  # DAG端口号
