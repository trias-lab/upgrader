# -*- coding: utf-8 -*-
import ntplib
import time
import http.client

from mylogger.trias_logger import LOGGER


def get_network_time():
    net_time = None
    conn = None
    resp = None
    try:
        conn = http.client.HTTPConnection("www.baidu.com", timeout=5)
        conn.request("GET", "/")
        resp = conn.getresponse()
        # 获取http头date部分
        gmt_time = resp.getheader('date')
        gmt_format = '%a, %d %b %Y %H:%M:%S GMT'
        timestamp = time.mktime(time.strptime(gmt_time, gmt_format))
        net_time = int(timestamp)
    except Exception as e:
        LOGGER.error(e)
    finally:
        if conn:
            conn.close()
        if resp:
            resp.close()

    if not net_time:
        c = ntplib.NTPClient()
        try:
            response = c.request('pool.ntp.org', timeout=5)
            net_time = int(response.tx_time)
        except Exception as e:
            LOGGER.error(e)

    if not net_time:
        net_time = int(time.time())

    return net_time


if __name__ == "__main__":
    ct = get_network_time()
    print(ct)
