# -*- coding: utf-8 -*-


def exist(db_src, key):
    """
        判断leveldb中是否存在key
        :param db_src:
        :param key:
        :return:
        """
    try:
        _key_obj = key.encode("utf-8")
        db_src.Get(_key_obj)
        return True
    except KeyError:
        return False
