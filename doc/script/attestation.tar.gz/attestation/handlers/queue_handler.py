# -*- coding: utf-8 -*-

import time
import leveldb
import pickle

from queue import Queue

from config import configs
from utils import leveldb_utils
from mylogger.trias_logger import LOGGER


# whitelist队列 保存节点广播的白名单
WHITELIST_QUEUE = Queue(maxsize=1000)

# 白名单数据库
WHITELIST_DB = leveldb.LevelDB(configs.WHITELIST_DB_DIR,  create_if_missing=True)


def update_whitelist():
    while True:
        if not WHITELIST_QUEUE.empty():
            try:
                item = WHITELIST_QUEUE.get()  # 格式(host_ip,[[file_path,file_hash]...])
                host_ip = item[0]
                whitelists = item[1]

                if leveldb_utils.exist(WHITELIST_DB, host_ip):
                    wls = WHITELIST_DB.Get(host_ip.encode("utf-8"))
                    wls_dict = pickle.loads(wls)
                    for whitelist in whitelists:
                        file_path = whitelist[0]
                        file_hash = whitelist[1]
                        wls_dict[file_path] = file_hash

                    WHITELIST_DB.Put(host_ip.encode("utf-8"), pickle.dumps(wls_dict))
                else:
                    content = {}
                    for whitelist in whitelists:
                        file_path = whitelist[0]
                        file_hash = whitelist[1]
                        content[file_path] = file_hash

                    WHITELIST_DB.Put(host_ip.encode("utf-8"), pickle.dumps(content))
            except Exception as e:
                LOGGER.error(e)
        time.sleep(0.1)
