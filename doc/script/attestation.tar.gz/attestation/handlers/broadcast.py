# -*- coding: utf-8 -*-
"""
向节点中广播信息
"""
import zmq
import json
import requests

from config.configs import TM_PORT
from mylogger.trias_logger import LOGGER
from utils import net_utils

# 本地IP
LOCAL_IP = net_utils.get_host_ip()


def broad_kernel(msg):
    """
    调用gossip 广播kernel
    :param msg:
    :return:
    """
    resp = None
    try:
        if msg:
            port = "46657"

            url = "http://" + LOCAL_IP + ":" + port

            data = {
                "data": str(msg)
            }

            # 发送信息
            resp = requests.get(url + "/tri_broadcast_kernel", params=convert_args(data), timeout=(5, 10), headers={'Connection': 'close'})
    except Exception as e:
        LOGGER.error(str(e))
    finally:
        if resp:
            resp.close()


def broadcast_ranking(ranking):
    """
    广播最新排名ranking
    :param ranking:
    :return:
    """
    tm_url = "http://localhost:" + str(TM_PORT)
    trans = json.dumps(ranking).replace('"', "'", -1)
    tx_url = tm_url + "/broadcast_tx_async?tx=\"" + trans + "\""
    requests.get(tx_url, timeout=2, headers={'Connection': 'close'})


def convert_args(args):
    args = args or {}
    for k, v in args.items():
        args[k] = to_hex(v)
    return args


def hex_prefix(value):
    if value[:2] == b'0x':
        return value
    return b'0x' + value


def to_hex(value):
    import binascii
    if isinstance(value, bytes):
        return hex_prefix(binascii.hexlify(value))
    if isinstance(value, str):
        return hex_prefix(binascii.hexlify(value.encode('utf-8')))
    if isinstance(value, int):
        return value


def broadcast_validators(msg):
    context = None
    socket = None
    try:
        context = zmq.Context()
        #  Socket to talk to server
        socket = context.socket(zmq.REQ)
        socket.linger = 2000

        socket.connect("tcp://" + LOCAL_IP + ":5672")  # 发送证实节点变更
        socket.send(bytes(str(msg), encoding="utf8"), flags=zmq.NOBLOCK)
        LOGGER.info("[TRIAS_INFO]: handle_msg successfully...")
    except Exception as e:
        LOGGER.error(str(e))
    finally:
        if socket:
            socket.close()

        if context:
            context.term()
