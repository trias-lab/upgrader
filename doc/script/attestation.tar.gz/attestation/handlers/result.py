def response(status, msg, result):
    """
    返回结果
    :param status: 返回状态 0失败  1正确
    :param msg: 提示信息
    :param result: 具体返回结果
    :return: 
    """
    res = {
        'status': status,
        'msg': msg,
        'result': result
    }
    return res
