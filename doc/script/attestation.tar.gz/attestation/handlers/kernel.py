# -*- coding: utf-8 -*-

"""
    该模块负责处理可信证实矩阵，包括更新矩阵、数据合并。 矩阵格式如下：
    {
        challenger_ip:{
            node_ip:[bitmap, 不良征信, 节点状态]
        },
        challenger_ip:{
            node_ip:[bitmap, 不良征信, 节点状态]
        },
        .
        .
        .
        timestamp: utc-time
    }
"""
import re

from mylogger.trias_logger import LOGGER


def get_ranking_list(kernel, num=None, excluded_node=None):
    """
    计算节点可信算力排行榜
    :param kernel: kernel数据
    :param num: 返回排行榜中前多少个节点
    :param excluded_node: 排除节点，将该节点从排名中去除
    :return:
    """
    ranking_list = []
    try:
        nodes = {}  # 保存所有节点的的可信值
        distrusted_nodes = []

        for c_node in kernel.keys():
            if re.match(r"\d+\.\d+\.\d+\.\d+", c_node):
                for v_node in kernel[c_node].keys():
                    if int(kernel[c_node][v_node][2]) == 0:
                        distrusted_nodes.append(v_node)
                    elif int(kernel[c_node][v_node][2]) == 1:
                        if v_node not in nodes.keys():
                            nodes[v_node] = int(kernel[c_node][v_node][1])
                        else:
                            if int(kernel[c_node][v_node][1]) > int(nodes[v_node]):
                                nodes[v_node] = int(kernel[c_node][v_node][1])

        # excluded node
        if excluded_node and excluded_node in nodes.keys():
            del nodes[excluded_node]

        # 排除证实出错节点
        for d_node in distrusted_nodes:
            if d_node in nodes.keys():
                del nodes[d_node]

        items = nodes.items()
        back_items = [[v[1], v[0]] for v in items]
        back_items.sort(reverse=True)

        if num:
            ranking_list = back_items[0:num]
        else:
            ranking_list = back_items
    except Exception as e:
        LOGGER.error("[TRIAS_ERROR]: " + str(e))
    return ranking_list
