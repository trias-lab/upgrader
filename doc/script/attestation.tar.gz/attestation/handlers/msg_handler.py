# -*- coding: utf-8 -*-

import hashlib
import binascii
import subprocess
import time
import pickle
import requests
import gc
import json
import threading

from config.configs import DAG_PORT
from .queue_handler import WHITELIST_DB
from mylogger.trias_logger import LOGGER
from .loop_timer import LoopTimer
from .result import response
from utils import leveldb_utils, time_utils, wechat
from handlers.broadcast import broadcast_validators, LOCAL_IP


# 程序启动时间
START_TIME = int(time.time())
# 证实队列  key是ip地址， value是端口号
VERIFY_NODE_DICT = {}
# {"出错节点ip":"证实出错时间"} 证实出错以后 清空可信值并暂停5分钟对其证实
DISTRUSTFUL_NODES_DICT = {}
# 证实节点，读取ima的行数 { ip: ima行数, ip: ima行数...}
IMA_LINE_NUM = {}
# 创建ima文件锁
ima_lock = threading.Lock()
# 创建读取出错节点锁
distrustful_lock = threading.Lock()


def start_verify(node_ip, node_port):
    """
    启动可信证实,并将该节点添加到定时器任务中
    :param node_ip: 节点ip
    :param node_port: 节点端口号
    :return:
    """
    try:
        distrustful_lock.acquire()
        dis_nodes_keys = list(DISTRUSTFUL_NODES_DICT.keys())
        distrustful_lock.release()

        if node_ip not in VERIFY_NODE_DICT.keys() and node_ip not in dis_nodes_keys:
            # 创建定时器, 证实间隔10秒
            loop_timer = LoopTimer(10, deal_verify_with_dag, (LOCAL_IP, node_ip, node_port))
            loop_timer.start()
            LOGGER.info("Timer: start " + node_ip + " timer...")
            # 保存定时器
            VERIFY_NODE_DICT[node_ip] = loop_timer

        LOGGER.info("[TRIAS_INFO]: current verify dict:>>> " + str(VERIFY_NODE_DICT))

        result = response('1', "start verify successfully.", None)

        return result
    except Exception as e:
        error_msg = str(e)
        LOGGER.error("[TRIAS_ERROR]: NODE:" + node_ip + " " + error_msg)
        result = response('0', error_msg, None)
        return result


def stop_verify(node_ip):
    """
    停止保护 将该trust agent从定时器中去除
    :param node_ip:  节点ip
    :return:
    """
    try:
        msg = "stop verifying NODE:" + node_ip
        LOGGER.info("[TRIAS_INFO]: " + msg)

        if node_ip in VERIFY_NODE_DICT.keys():
            loop_timer = VERIFY_NODE_DICT[node_ip]
            loop_timer.cancel()
            # 删除
            del VERIFY_NODE_DICT[node_ip]

        LOGGER.info("[TRIAS_INFO]: current verify dict:>>> " + str(VERIFY_NODE_DICT))

        result = response('1', msg, None)
        return result
    except Exception as e:
        error_msg = str(e)
        LOGGER.error("[TRIAS_ERROR]: " + error_msg)
        result = response('0', error_msg, None)
        return result


def get_node_info(ima_line=0):
    """
    获取节点的ima和kernel
    :param ima_line: 读取的ima起始行数
    :return:
    """
    # 初始化ima文件对象
    ima_file_obj = None
    # 初始化最新行数
    new_last_num = ima_line
    try:
        """ 暂时不是用pcr
        # 获取pcr
        pcr = get_tpm_pcr()

        if pcr is False:
            msg = "can not get prc."
            LOGGER.error(msg)
            result = response('0', msg, None)
            return result
        """
        # TODO 默认暂时为0
        pcr = '0' * 40

        # 获取ima文件对象
        ima_file_obj = open("/sys/kernel/security/ima/ascii_runtime_measurements")

        ima_list = []
        for count, line in enumerate(ima_file_obj):
            if ima_line == 0:  # 如果last_num==0， 说明是首次读取ima， 全部读取
                ima_list.append(line)
                new_last_num = count
            elif ima_line < count:  # 如果last_num不为0，说明以前读取过， 只需读取最新即可
                ima_list.append(line)
                new_last_num = count

        if ima_list:
            measurements = ''.join(ima_list)
        else:
            measurements = ''

        result = response('1', "success", {"pcr": pcr, "ml": measurements, "new_num": new_last_num})
    except Exception as e:
        error_msg = str(e)
        LOGGER.error("[TRIAS_ERROR]: " + error_msg)
        result = response('0', error_msg, None)
    finally:
        # 释放文件
        if ima_file_obj:
            ima_file_obj.close()

    return result


def verify(node_ip, node_port):
    """
    验证node是否可信
    :param node_ip:
    :param node_port:
    :return:
    """

    LOGGER.info("[TRIAS_INFO]: start verifying Node:" + node_ip)

    # 存储ima中有异常的文件  key为文件名 value为hash
    ima_exception_dict = {}
    # 初始化0*40
    zero_template_hash = '0' * 40
    # 初始化F*40
    repl_template_hash = 'F' * 40

    resp = None
    try:
        # step1 query whether the white list exists
        if not leveldb_utils.exist(WHITELIST_DB, node_ip):
            msg = "node:" + node_ip + " the white list does not exist."
            LOGGER.error("[TRIAS_ERROR]: " + msg)

            result = response('9999', msg, None)  # 9999 表示白名单不存在 暂不合并kernel
            return result

        node_url = "http://" + node_ip + ":" + str(node_port)
        # 设置重试次数
        requests.adapters.DEFAULT_RETRIES = 1
        r_session = requests.session()
        r_session.keep_alive = False
        req_header = {"Content-Type": "application/x-www-form-urlencoded"}

        # 获取证实节点的读取行数
        if node_ip in IMA_LINE_NUM.keys():
            # 获取锁
            ima_lock.acquire()
            read_line = IMA_LINE_NUM[node_ip]
            # 释放锁
            ima_lock.release()
        else:
            read_line = 0

        req_data = {
            "ima_line": read_line,
            "request_from": "verify"
        }
        # 请求获取节点可信信息 timeout=(30,120) 30s表示连接超时时间 120s表示读取超时时间
        resp = r_session.get(node_url + "/trias/getnodeinfo", data=req_data, headers=req_header, timeout=(30, 120))

        resp_dict = resp.json()
        if int(resp_dict["status"]) == 0:
            LOGGER.error("[TRIAS_ERROR] get node:" + node_ip + " info error," + resp_dict["msg"])
            result = response('2', resp_dict["msg"], None)
            return result

        # 被证实机器的PCR值
        pcr_value = resp_dict["result"]["pcr"]
        # 被证实机器的可信度量值
        measurements = resp_dict["result"]["ml"].strip().split("\n")
        # 读取ima的行数
        ima_line = resp_dict["result"]["new_num"]

        LOGGER.info("[TRIAS_INFO]: the length of measurements is: " + str(len(measurements)))

        # 初始化PCR值
        pcr = bytes.fromhex(zero_template_hash)

        white_list = WHITELIST_DB.Get(node_ip.encode("utf-8"))
        white_list = pickle.loads(white_list)
        LOGGER.info("[TRIAS_SQLITE]: the length of whitelist: " + str(len(white_list.keys())) + "!")

        # 记录measurements文件行数
        line_numbers = 1

        for measure in measurements:
            if measure.find("ima") != -1:
                # 获取template_hash
                template_hash = measure[3:43]
                # 判断template_hash长度是否合法
                if len(template_hash) != 40:
                    msg = "Invalid Measure Format. " + "Line: " + str(line_numbers)
                    LOGGER.error("[TRIAS_ERROR]: " + msg)
                    LOGGER.error("[TRIAS_ERROR]: >>> error hash: " + template_hash)

                    result = response('0', msg, None)
                    return result

                # 获取文件hash和路径 用来和数据库中该主机的白名进行单对比
                file_hash = measure[48:88]
                file_path = measure[measure.rindex(" ") + 1:len(measure)]

                # 标记当前文件是否需要被过滤掉
                is_filter = False

                if file_hash == zero_template_hash:
                    is_filter = True
                else:
                    """
                    # TODO 包含以下字符串 该文件则过滤
                    filter_list = ["proc/", ".rpmdb/", "/var/lib", "/var/log", "/txmodule",
                                   "/root/.ssh/known_hosts", "intel/cloudsecurity", "ntp/drift", ".bash_history",
                                   "/usr/local/aegis", "/8lab/Agentclient", "/tmp", "/root/ima",
                                   "__pycache__", ".Xauthority", "/sys/fs/cgroup", "/python3.4/dist-packages",
                                   "/blackbox/", "/usr/lib/x86_64-linux-gnu", "/usr/share/vim",
                                   "/usr/share/bash-completion", "/root/.ipfs", "/var/backups",
                                   "/usr/lib/python", "/.viminfo", "/8lab/log", "/sys/fs/cgroup/systemd/user/",
                                   "/var/opt/intel/aikverifyhome/", "/var/cache", "/attestation", "/trias",
                                   "/data/mysql3306/logs/audit.log"]

                    for filter_file in filter_list:
                        if file_path.find(filter_file) != -1:
                            is_filter = True
                            break
                    """
                    # 演示临时操作  缩小可信防护范围
                    tmp_list = ["/root/.viminfo", "/root/.bash_history", "/root/var", "/root/.ssh", "/root/.ipfs",
                                "/root/.ansible", "/root/.Xauthority"]
                    if file_path.find("/root") != -1:
                        is_filter = False
                    else:
                        is_filter = True

                    if not is_filter:
                        for tmp_file in tmp_list:
                            if file_path.find(tmp_file) != -1:
                                is_filter = True
                                break

                # 如果该文件不在过滤列表中  则和数据库中的白名单进行对比
                if not is_filter:
                    # 和数据库白名单对比，白名单中包含该文件名，并且hash相同的 验证通过 如果以前在ima_exception中，则删除
                    # 如果该文件在白名单中没有 则说明是非法文件，则添加到ima_excepiont列表中
                    if file_path in white_list.keys():
                        # 如果hash和白名单中相同，并且在 ima_exception字典中，则从字典中删除该文件
                        if white_list[file_path] == file_hash:
                            ima_exception_keys = ima_exception_dict.keys()
                            if file_path in ima_exception_keys:
                                del ima_exception_dict[file_path]
                        else:
                            ima_exception_dict[file_path] = file_hash
                    else:
                        ima_exception_dict[file_path] = file_hash

                # 开始计算PCR的值
                # PCR[i] = SHA-1(PCR[i-1] || new-measurement)
                hash_method = hashlib.sha1()
                hash_method.update(pcr)

                # 如果template_hash值是0，则替换为全F
                if template_hash == zero_template_hash:
                    template_hash = repl_template_hash

                hash_method.update(bytes.fromhex(template_hash))
                # 重新计算pcr值
                pcr = hash_method.digest()

                line_numbers = line_numbers + 1

        # 将计算出的pcr转换成16进制字符串
        calc_pcr = bytes.decode(binascii.hexlify(pcr))
        LOGGER.info("[TRIAS_INFO]: calc PCR by ima: " + calc_pcr + " <=> " + pcr_value)

        # 如果有非法文件 将该文件输出到日志文件中
        if ima_exception_dict:
            LOGGER.error(
                '[TRIAS_ERROR]: + >>> ' + node_ip + ' has ' + str(len(ima_exception_dict)) + ' ima verify exception...')

            for ex_key in ima_exception_dict:
                LOGGER.error(
                    "[TRIAS_ERROR]: >>> node:" + node_ip + " error_file_path:" + ex_key + "; error_file_hash:" +
                    ima_exception_dict[
                        ex_key])
                if ex_key in white_list.keys():
                    LOGGER.error("[TRIAS_ERROR]:  >>> file_expected_hash:" + white_list[ex_key])

            msg = "Verify " + node_ip + " Failed."
            LOGGER.error("[TRIAS_ERROR]: " + msg)

            result = response('0', msg, None)

            return result

        # 虚拟TPM pcr值都是0000000000000000000000000000000
        if pcr_value == zero_template_hash:
            msg = "Verify " + node_ip + " Successfully."
            LOGGER.info("[TRIAS_INFO]: " + msg)

            result = response('1', msg, {"new_num": int(ima_line)})

            return result

        # 判断pcr值是否相等
        if calc_pcr == pcr_value:
            LOGGER.info("[TRIAS_INFO] matches, the data should be append into white_list , PCR is " + calc_pcr)

            msg = "Verify " + node_ip + " Successfully."
            LOGGER.info("[TRIAS_INFO]: " + msg)

            result = response('1', msg, {"new_num": int(ima_line)})

            return result

        msg = "Verify " + node_ip + " Failed."
        LOGGER.error("[TRIAS_ERROR]: " + msg)

        result = response('0', msg, None)

        return result

    except Exception as e:
        msg = str(e)
        LOGGER.error("[TRIAS_ERROR]: NODE:" + node_ip + " " + str(e))
        result = response('0', msg, None)
        return result
    finally:
        if resp:
            resp.close()


def get_tpm_pcr():
    """
    得到TPM的PCR值,返回值就是TPM的PCR值，目前默认是PCR10
    return：如果存在TPM芯片并且正确工作，那么返回值是真实读到PCR10值，如果不存在TPM芯片那么返回的是1
    """
    # 注意这个地方使用的时候必须是root权限
    (status, output) = subprocess.getstatusoutput("/8lab/control_prc")
    if status == 1:
        LOGGER.error("[TRIAS_ERROR] 需要root权限部署八分量完整性度量工具，需要开启linux系统的ima值，请检查")
        return False
    temp_pcr_list = output
    temp_pcr_list = temp_pcr_list.split("\n")
    for line in temp_pcr_list:
        temp_string = line.strip()
        temp_ptr = temp_string.find("PCR 10")
        if temp_ptr != -1:
            list_result = temp_string.split(" ")
            if list_result[2] == "00000000000000000000000000000000000000" or \
                    list_result[2] == "ffffffffffffffffffffffffffffffffffffff":  # 得到PCR10的值
                return False
            else:
                return list_result[2]

    return False


def deal_verify_with_dag(local_ip, host_ip, host_port):
    """
    结合dag，通过调用DAG的投票接口，完成可信值计算
    :param local_ip:
    :param host_ip:
    :param host_port:
    :return:
    """
    verify_result = None
    add_resp = None
    query_resp = None
    try:
        res = verify(host_ip, host_port)
        verify_result = res['status']

        if int(verify_result) == 9999:  # 9999说明白名单不存在 暂不合并kernel
            return
        elif int(verify_result) == 1:
            # 更新本地读取行数
            ima_lock.acquire()
            IMA_LINE_NUM[host_ip] = int(res['result']['new_num'])
            ima_lock.release()

            current_time = int(time.time())
            delta_time = current_time - START_TIME
            # 如果时间小于0 说明时间被修改过
            if delta_time <= 0:
                delta_time = 0 - delta_time

            data = {
                "Attester": local_ip,
                "Attestee": host_ip,
                "Score": str(delta_time)
            }

            headers = {
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }

            req_url = "http://127.0.0.1" + ":" + str(DAG_PORT) + "/AddNode"
            requests.adapters.DEFAULT_RETRIES = 1
            r_session = requests.session()
            r_session.keep_alive = False
            # 向dag发起证实请求
            add_resp = r_session.post(req_url, headers=headers, data=json.dumps(data), timeout=(3, 9))
        elif int(verify_result) == 0:
            # 更新本地读取行数
            ima_lock.acquire()
            # 证实失败 下次读取ima从0读取
            IMA_LINE_NUM[host_ip] = 0
            ima_lock.release()

            current_time = int(time.time())
            delta_time = current_time - START_TIME
            if delta_time > 0:
                delta_time = 0 - delta_time

            # 证实出错 投票复数
            headers = {
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }

            att_data = {
                "Attester": local_ip,
                "Attestee": host_ip,
                "Score": str(delta_time)
            }

            # 向dag发起证实请求
            req_url = "http://127.0.0.1" + ":" + str(DAG_PORT) + "/AddNode"
            requests.adapters.DEFAULT_RETRIES = 1

            r_session = requests.session()
            r_session.keep_alive = False
            # 向dag发起证实请求
            add_resp = r_session.post(req_url, headers=headers, data=json.dumps(att_data), timeout=(3, 9))

            # 读取非可信节点
            distrustful_lock.acquire()
            dis_node_keys = list(DISTRUSTFUL_NODES_DICT.keys())
            distrustful_lock.release()

            # 如果该节点不在非可信字典中， 发起证实节点变更
            if host_ip not in dis_node_keys:
                # 获取最新计算可信排名
                query_data = {
                    "period": -1,   # -1 表示最新周期
                    "numRank": 10
                }

                req_url = "http://127.0.0.1" + ":" + str(DAG_PORT) + "/QueryNodes"
                r_session = requests.session()
                r_session.keep_alive = False
                # 向dag发起证实请求
                query_resp = r_session.post(req_url, headers=headers, data=json.dumps(query_data), timeout=(3, 9))
                resp_str = query_resp.content.decode("utf-8")
                resp_dict = json.loads(resp_str)

                ranking = []
                if resp_dict["Code"] == 1:
                    data_score = resp_dict["Data"]["DataScore"]
                    for idx, val in enumerate(data_score):
                        if val["attestee"] != host_ip and val["attestee"] not in dis_node_keys:
                            ip = val['attestee']
                            score = val['score']
                            tmp_array = [score, ip]
                            ranking.append(tmp_array)

                    # 返回最新的节点排名
                    ranking = ranking[:7]

                LOGGER.error("[TRIAS_ERROR]: new validators:" + str(ranking))

                change_nodes = {"ranking": ranking, "action": "attack"}
                # 广播新的验证者
                broadcast_validators(change_nodes)
                # content = "Attestation Error: " + local_ip + " verify " + host_ip + " unsuccessfully. New validators: " + str(ranking)
                # 向微信发送变更信息
                # wechat.send_wechat(content)
    except Exception as e:
        LOGGER.error("[TRIAS_ERROR]: " + str(e))
    finally:
        if add_resp:
            add_resp.close()

        if query_resp:
            query_resp.close()

        if verify_result and int(verify_result) != 1:
                # 从证实节点字典中删除该ip, 并停止timer
                if host_ip in VERIFY_NODE_DICT.keys():
                    loop_timer = VERIFY_NODE_DICT[host_ip]
                    loop_timer.cancel()
                    # 删除host
                    del VERIFY_NODE_DICT[host_ip]


def handle_distrustful_nodes():
    """
    处理不可信节点，证实出错的节点会有所惩罚，清空可信值并且3分钟之内不对其进行证明
    :return:
    """
    while True:
        try:
            current_timestamp = time_utils.get_network_time()
            # 获取锁
            distrustful_lock.acquire()
            for node_ip in list(DISTRUSTFUL_NODES_DICT.keys()):
                verify_timestamp = DISTRUSTFUL_NODES_DICT[node_ip]
                del_sec = current_timestamp - int(verify_timestamp)
                # 如果时间间隔超过3分钟 从不可信节点中去处
                if int(del_sec) >= 180:
                    del DISTRUSTFUL_NODES_DICT[node_ip]
            # 释放锁
            distrustful_lock.release()

            # 睡眠5秒钟
            time.sleep(5)
        except Exception as e:
            LOGGER.error(e)


def clear_mem():
    """清理内存"""
    try:
        gc.collect()
    except Exception as e:
        LOGGER.error(e)


if __name__ == "__main__":
    handle_distrustful_nodes()
