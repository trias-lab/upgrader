# Attestation  

![build](https://img.shields.io/badge/build-passing-success.svg)
[![Python version](https://img.shields.io/badge/python-3.6-blue.svg)](https://github.com/moovweb/gvm)
[![license](https://img.shields.io/badge/license-GPLv3-green.svg)](https://github.com/trias-lab/gondwana/blob/master/LICENSE)

可信证实模块是Trias中一个独立模块，该模块需要和黑盒子模块（Trias另外一个模块）配合工作，每个节点上都运行了可信证实模块和黑盒子模块。可信模块提供了远程证实、可信值计算、发起节点变更等功能。黑盒子模块主要提供了发起远程证实以及提供初始化节点可信状态信息功能。

## 安装

Requirement|Notes
---|---
Python version|Python 3.4 or higher

由于该模块需要配合其余模块工作，跟随Trias启动，并未提供安装包，未来版本会增加其他安装方式，方便开发者更快捷的安装。运行该模块，至少需要提供python3.4执行环境，您可以到[Python官网](https://www.python.org/)安装相应版本。

## 快速启动

查看主目录下是否有8lab文件夹，如果不存在8lab文件夹，执行以下命令：
```shell
cd /
mkdir 8lab
chmod -R 777 /8lab
```
下载源代码，进入目录以后,执行命令:
```shell
python3 attestation.py
```
默认使用8987端口,如果启动失败查看是否缺少相关引用包，可信证实模块主要使用到了以下几个模块：

*leveldb、zmq、gflags、requests、pickle*

如果启动过程中本地缺少相应模块，可以通过命令`pip3 install 模块名`进行安装。

## 可信证实原理和流程

可信证实模块主要通过使用获得的最新可信状态信息和黑盒子提供的默认可信状态信息进行对比，来确定被证实节点的可信状态，具体流程如下：

1. 黑盒子模块不断执行摇骰子，当摇出骰子以后向全网广播，让其余节点来挑战摇出骰子的节点。
2. 收到骰子的节点会向产生骰子的节点请求可信状态信息，并将获得状态信息保存，之后该节点中的黑盒子模块会通知可信计算模块去挑战产生骰子的节点，进行远程可信证实。（该版本中的可信状态信息是通过黑盒子获取，以后版本可能会提供更好更方便的方式）
3. 可信计算模块向产生骰子发起获取可信状态请求，获取相应可信状态以后和保存在本地的该节点的可信状态进行对比，如果信息一致则表示可信，如果信息不一致则为不可信。（该版本中暂未使用TPM或者TPM模拟器，未来版本会逐步添加对TPM和TPM模拟器的支持）
4. 可信模块将远程证实结果以字节数组的形式保存，最后根据该数组计算出一段时间内该节点的可信值。当被挑战的节点证实状态为不可信时，将该节点的可信值清零，同时更新字节数组，并结算数组中所有节点的可信值，将可信值最高的几个节点发送给Trias节点管理模块，发起共识节点变更，节点管理模块会根据接受到的信息判断是否变更共识节点。
5. 如果节点变更成功，Trias则会使用最新的共识节点进行共识。

## 接口说明

可信证实模块主要提供了黑盒子消息处理、节点证实信息查询、节点变更等接口。请求ip地址为节点地址，以下接口说明暂用localhost替代。
1. 黑盒子消息处理接口，主要处理黑盒子请求，包括发起证实、停止证实、更新白名单请求。
- 接口地址：http://localhost:8987/trias/msghandle/
- 请求方式：POST
- 请求参数
    - node_ip   字符串，目标节点ip地址（必须）
    - node_port 整数，目标节点端口号
    - content   数组，节点白名单，格式[[file_path,file_hash],[file_path,file_hash]...]
    - action    整数，操作类型，1 更新白名单，2 启动证实， 3 停止证实
- 返回结果：json，`{
        'status': 1表示成功，0表示失败,
        'msg': 错误信息,
        'result': 具体返回结果
    }`
    
2. 获取节点正在证实哪些节点
- 接口地址：http://localhost:8987/trias/getverifynodes/
- 请求方式：GET
- 请求参数：无
- 返回结果：节点ip地址数组 例如['127.0.0.1'...]

3. 获取证实出错的节点，如果正在证实的节点出错，会被惩罚3分钟，3分钟之内不会证实错误节点。
- 接口地址：http://localhost:8987/trias/getdistrustfulnodes/
- 请求方式：GET
- 请求参数：无
- 返回结果：json，`{'node_ip':timestamp,'node_ip':timestamp...}`